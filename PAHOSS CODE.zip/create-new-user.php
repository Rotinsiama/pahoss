<?php
header("X-Frame-Options:DENY");
header_remove("Server");
header_remove("X-Powered-By");
header_remove("X-Frame-Options");
session_start();
include 'conn.php';
include 'log.php';
if (isset($_POST['reset-password-submit'])) 
{
	$selector = $_POST['selector'];	
	$token = $_POST['token'];
	$password1 = $_POST['password1'];
	$password2 = $_POST['password2'];

	if(empty($password1) || empty($password2))
	{
		echo '<script>{alert("Enter New Password...");}</script>';
			?>
				<script>
					function goBack() 
					{
					  	window.history.back();
					}
					goBack();
				</script>
			<?php
		exit();
	}
	elseif ($password1!=$password2) 
	{
		echo '<script>{alert("Enter Password are not Match...");}</script>';
			?>
				<script>
					function goBack() 
					{
					  	window.history.back();
					}
					goBack();
				</script>
			<?php
		exit();
	}

	$currentDate = date("U");
	
	$stmt = $conn->prepare("SELECT token, email FROM `newuser` WHERE selector=? AND expires>=$currentDate;");
	$stmt->bind_param('s', $selector);
    $stmt->execute();
    $stmt->bind_result($dbtoken, $dbemail);// get the database output
    $stmt->store_result();
    if($stmt->num_rows == 1)  //To check if the row exists
    {
		// output data of each row
		if($stmt->fetch()) 
		{

			$tokenn =hex2bin($token);
        	$tokencheck = password_verify($tokenn, $dbtoken);
        	if($tokencheck === false)
        	{
	            logger('create-new-user.php Someone try to make Ac using Invalid/Expired Link and it Fail');
				echo '<script>{alert("Invalid link OR Token expired...");}</script>';
				echo '<script>{location.replace("login.php?error=Invalid link")}</script>';
				exit();
        	}
        	elseif($tokencheck === true)
        	{

	            $sql = "INSERT INTO `users` (`id`, `password`, `email`, `salt`) VALUES (NULL, ?, '$dbemail', ?);";
	            $stmt = mysqli_stmt_init($conn);
	            if (!mysqli_stmt_prepare($stmt, $sql)) 
	            {
					    logger('create-new-user.php;'.$dbemail.' try to make Ac , due to server respnse slow it fail.');
						echo '<script>{alert("Something went wrong we could not make new account. Try Again...");}</script>';
						echo '<script>{location.replace("login.php?error=System error")}</script>';
						exit();
	            }
	            else
	            {
                    $length_of_string = 100;
                    $salt = substr(bin2hex(random_bytes($length_of_string)), 0, $length_of_string);
                    $pas = $password1.$salt;
                  	$newpwdhash  = hash('sha256', $pas);

					//$newpwdhash = md5($password1);
					mysqli_stmt_bind_param($stmt, 'ss',$newpwdhash, $salt);
					mysqli_stmt_execute($stmt);

			        $sql1 = "SELECT * FROM `users` ORDER BY id DESC LIMIT 1";
			        $result1 = $conn->query($sql1);
			        if ($result1->num_rows > 0) 
			        {
			            // output data of each row
			            while($row1 = $result1->fetch_assoc()) 
			            {
			                $id = $row1["id"];
			            }
			        }

					$sql = "DELETE FROM newuser WHERE email=?";
					$stmt = mysqli_stmt_init($conn);
					if (!mysqli_stmt_prepare($stmt,$sql)) 
					{
	                    logger('create-new-user.php;'.$dbemail.' make AC successfully');
						echo '<script>{alert("Succecfully make Account!!");}</script>';
						$_SESSION["thuruk_user"] = $id;
						echo '<script>{location.replace("enter_details.php)}</script>';
						exit();
					}
					else
				    {
			            mysqli_stmt_bind_param($stmt,"s", $dbemail);
			            mysqli_stmt_execute($stmt);
	                    logger('create-new-user.php;'.$dbemail.'make AC successfully');
						echo '<script>{alert("Succecfully Make Account!!");}</script>';
						$_SESSION["thuruk_user"] = $id;
						echo '<script>{location.replace("enter_details.php")}</script>';
						exit();
			        }
						
				}
        	}
		}
	}
	else 
	{
	    logger('reset-password.php Someone make AC using Invalid/Expired Link and it Fail');
	    echo "<script type='text/javascript'>alert('Expired link or Invalid Link!! Try Again')</script>";
		echo '<script>{location.replace("login.php?error=Expired link")}</script>';
		exit();
	}
}
else
{
	header("Location:login.php?error=Expired");
	exit();
}
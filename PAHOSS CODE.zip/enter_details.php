<?php
header("X-Frame-Options:DENY");
header_remove("Server");
header_remove("X-Powered-By");
header_remove("X-Frame-Options");
session_start();
if(isset($_SESSION['thuruk_user']))
{
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Pahoss</title>
    <link rel="icon" href="favicon.png" type="image/gif" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
<script type="text/javascript">
	var id = sessionStorage.getItem("tab-id");
	if (id==null) 
	{
		//location.replace("https://www.google.com/")
	}

    function showPosition() 
    {
        if(navigator.geolocation) 
        {
            navigator.geolocation.getCurrentPosition(function(position) 
            {
                var latitude =  position.coords.latitude;
                document.getElementById("lat").value = latitude;
                var longitude =  position.coords.longitude;
                document.getElementById("long").value = longitude;
            });
        } 
        else 
        {
            alert("Sorry, your browser does not support HTML5 geolocation.");
        }
        varr = "a"
    }
</script>
<style type="text/css">
  #input
  {
    width: 45%;
    float: left;
    height: 40px;
    margin: 10px 3px;
  }
  @media only screen and (max-width: 700px)
  {
    #input
    {
      width: 100%;
      height: 30px;
      margin: 10px 0px;
    }    
  }
  body
  {
      -webkit-touch-callout: none; /* iOS Safari */ 
      -webkit-user-select: none; /* Safari */ 
       -khtml-user-select: none; /* Konqueror HTML */ 
         -moz-user-select: none; /* Firefox */ 
          -ms-user-select: none; /* Internet Explorer/Edge */ 
              user-select: none; /* Non-prefixed version, currently 
                                    supported by Chrome and Opera */      
  }  
</style>
  <body class="app sidebar-mini">

    <?php include "app-menu2.php";?>
    
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-edit"></i>ENTER YOUR DETAILS</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="#">New User</a></li>
        </ul>
      </div>
      <div style="width: 100%;float: left;text-align: center;background-color: lightgray;padding: 20px;">
        <div style="width: 100%;float: left;text-align: center;color: gray; ">
          <h4>Enter your details:</h4>
        </div>

        <div style="width: 100%;float: left;text-align: center; margin: 20px 0px;">
          <form action="up_newuser_data.php" method="POST">
            <input id="input" type="text" name="name" placeholder=" Enetr name" >
            <div id="input" style='display: inline-flex;' >
              Gender: Male<input type="radio" name="gender" value="male" checked="true" style="margin-left: 20px; margin-right: 20px; ">
              Female<input type="radio" name="gender" value="female" style="margin-left: 20px;" >
            </div>
            <input id="input" type="number" name="mobile" placeholder=" Enetr Mobile number" >
            <textarea placeholder=" Enter Address" name="address" id="input"></textarea>
            <div id="input">
              <select name="vehicle_type" style="width: 100%; height: 100%;">
                <option value="Vehicle Type">Vehicle Type</option>
                <option value="2">Two wheeler</option>
                <option value="4">Two wheeler</option>
                <option value="both">Both</option>
              </select>
          </div>
            <input id="input" type="text" name="vehicle_number" placeholder=" Enetr   Vehicle Number" >
            <div id="input">
              <input id="lat" type="text" name="gps_lat" placeholder="Don't Enter  here">
              <input id="long" type="text" name="gps_long" placeholder="Don't Enter  here">              
            </div>

            <input id="input" style="height: 40px;" onclick="showPosition();" type="button" name="submit" value="Get Current GPS coordinate" class="btn btn-primary">
            <input style="height: 50px" id="input" type="submit" name="submit" value="submit" class="btn btn-primary">
          </form>
        </div>      
      </div>
    </main>
    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <!-- Google analytics script-->
    <script type="text/javascript">
      if(document.location.hostname == 'pratikborsadiya.in') {
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
        ga('create', 'UA-72504830-1', 'auto');
        ga('send', 'pageview');
      }
    </script>
  </body>
</html>
<?php
}
else
{
  echo '<script>{location.replace("login.php")}</script>';
}
?>
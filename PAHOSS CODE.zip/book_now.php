<?php
header("X-Frame-Options:DENY");
header_remove("Server");
header_remove("X-Powered-By");
header_remove("X-Frame-Options");
session_start();
if(isset($_SESSION['thuruk_user']))
{
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Pahoss</title>
    <link rel="icon" href="favicon.png" type="image/gif" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
<script type="text/javascript">
	var id = sessionStorage.getItem("tab-id");
	if (id==null) 
	{
		//location.replace("https://www.google.com/")
	}
</script>
<style type="text/css">
  body
  {
      -webkit-touch-callout: none; /* iOS Safari */ 
      -webkit-user-select: none; /* Safari */ 
       -khtml-user-select: none; /* Konqueror HTML */ 
         -moz-user-select: none; /* Firefox */ 
          -ms-user-select: none; /* Internet Explorer/Edge */ 
              user-select: none; /* Non-prefixed version, currently 
                                    supported by Chrome and Opera */      
  }
  .data
  {
    margin: auto; 
    width: 50%; 
    padding: 0px 5%; 
    text-align: left; 
    color: black; 
    font-size: 15px;
  }
  @media only screen and (max-width: 700px)
  {
    .data
    {
      width: 100%;
      padding: 0px;
    }
  }
</style>
  <body id="body" class="app sidebar-mini">

    <?php include "app-menu.php";?>
    
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-edit"></i>BOOK SLOT NOW</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="home.php">Home</a></li>
        </ul>
      </div>
      <div style="width: 100%;float: left;text-align: center;background-color: lightgray;padding: 20px;">
        <div style="width: 100%;float: left;text-align: center;color: gray; padding-bottom: 20px;">
          <?php
            if(isset($_GET['owner_name']))
            {

              $id = $_SESSION['thuruk_user'];

              $sql = "SELECT name, email, mobile FROM users WHERE id = $id";
              $result = $conn->query($sql);

              if ($result->num_rows > 0) 
              {
                // output data of each row
                  while($row = $result->fetch_assoc()) 
                  {
                      $name = strip_tags($row["name"]);
                      $email = strip_tags($row["email"]);
                      $mobile = strip_tags($row["mobile"]);
                  }
              }

              $Pahoss_parking_name = strip_tags($_GET['owner_name']);
              $pahoss_parking_id = strip_tags($_GET['pahoss_parking_id']);
              $slot_id = strip_tags($_GET['slot_id']);

              $from = strip_tags($_GET['from']);
              $to = strip_tags($_GET['to']);
              $pricing = strip_tags($_GET['pricing']);

              //Cal totoal Amount

              $date1=date_create($from);
              $date2=date_create($to);
              $todate = Date('Y-m-d');

              if ( $todate > $from || $todate > $to ) 
              {
                echo("<script>{alert('Please Reseclect date:')}</script>");
                ?>
                <script>
                  function goBack() 
                  {
                      window.history.back();
                  }
                  goBack();
                </script>
                <?php
                exit();
              }
              elseif ($to < $from) 
              {
                echo "<script>{alert('Please Reseclect date: FROM date can not be grater then TO date.')}</script>";
                ?>
                <script>
                  function goBack() 
                  {
                      window.history.back();
                  }
                  goBack();
                </script>
                <?php                
                exit();
              }
              else
              {  
                $diff = date_diff($date1,$date2); 
                $price = ($pricing * ($diff->format("%a")+1));
              }
            ?>
            <div class="data" id="data">
              PAHOSS PARKING NAME:<?php echo $Pahoss_parking_name;?><br>
              PAHOSS PARKING ID:<?php echo $pahoss_parking_id;?><br>
              PARKING SLOT ID:<?php echo $slot_id;?><br>
              BOOKING START FROM:<?php echo $from;?><br>
              BOOKING END AT:<?php echo $to;?><br>
              RATE OF SLOT PER/DAY:<?php echo $pricing;?><br>
              <span style="color: green;">TOTAL AMOUNT:<?php echo $price;?></span><br><br>
            </div>
            <?php
              include 'temp_pay.php';
            }
            ?>
        </div>
      </div>
    </main>
    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <!-- Google analytics script-->
    <script type="text/javascript">
      if(document.location.hostname == 'pratikborsadiya.in') {
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
        ga('create', 'UA-72504830-1', 'auto');
        ga('send', 'pageview');
      }
    </script>
  </body>
</html>
<?php
}
else
{
  echo '<script>{location.replace("login.php")}</script>';
}
?>
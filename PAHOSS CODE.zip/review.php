<?php
header("X-Frame-Options:DENY");
header_remove("Server");
header_remove("X-Powered-By");
header_remove("X-Frame-Options");
session_start();
if(isset($_SESSION['thuruk_user']))
{
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Pahoss</title>
    <link rel="icon" href="favicon.png" type="image/gif" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
<script type="text/javascript">
	var id = sessionStorage.getItem("tab-id");
	if (id==null) 
	{
		//location.replace("https://www.google.com/")
	}
</script>
<style type="text/css">
  textarea
  {
    width: 50%;
    height: 100px;
  }
  @media only screen and (max-width: 700px)
  {
    textarea
    {
      width: 100%;
    }
  }
  #more
  {
    padding: 10px 20px; 
    background-color: white; 
    border-color: gray; 
    border-radius: 7px;
  }
  #more:hover
  {
    background-color: gray;
  }
  body
  {
      -webkit-touch-callout: none; /* iOS Safari */ 
      -webkit-user-select: none; /* Safari */ 
       -khtml-user-select: none; /* Konqueror HTML */ 
         -moz-user-select: none; /* Firefox */ 
          -ms-user-select: none; /* Internet Explorer/Edge */ 
              user-select: none; /* Non-prefixed version, currently 
                                    supported by Chrome and Opera */      
  }  
</style>

  <body class="app sidebar-mini">

    <?php include "app-menu.php";?>
    
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-edit"></i>Write Review/Feedback</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="home.php">Home</a></li>
        </ul>
      </div>
      <div style="width: 100%;float: left;text-align: center;background-color: lightgray;padding: 20px;">
        <div style="width: 100%;float: left;text-align: center;color: gray; padding-bottom: 20px;">
          <?php 
            if (isset($_GET['pahoss_parking_id'])) 
            {
              $pahoss_id = strip_tags($_GET['pahoss_parking_id']);
            }
            else
            {
              $pahoss_id = 0;
            }
          ?>
          <form action="review.php" method="POST"> 
            <textarea name="text" placeholder=" Type here.."></textarea>
            <br>
            Give rating:
            <br>
            <div style="display: inline-flex;">
            1<input type="radio" name="rate" value="1" style="height: 30px; width: 30px; margin-right: 10px;">
            2<input type="radio" name="rate" value="2" style="height: 30px; width: 30px; margin-right: 10px;">
            3<input type="radio" name="rate" value="3" style="height: 30px; width: 30px; margin-right: 10px;">
            4<input type="radio" name="rate" value="4" style="height: 30px; width: 30px; margin-right: 10px;">
            5<input type="radio" name="rate" value="5" style="height: 30px; width: 30px; margin-right: 10px;">
            <input type="hidden" name="pahoss_parking_id" value="<?php echo $pahoss_id;?>">
            </div>
            <br>
            <br>
            <input type="submit" name="submit" value="Submit" style="padding: 10px 30px; border: none; background-color: gray;border-radius: 5px;">
          </form>
        <?php

          if (isset($_POST['submit'])) 
          {
            $text = strip_tags($_POST['text']);
            $pahoss_parking_id = strip_tags($_POST['pahoss_parking_id']);
            $rate = strip_tags($_POST['rate']);
            $users_id = $_SESSION['thuruk_user'];
            include 'conn.php';
            $sql = "SELECT name FROM users WHERE id='$users_id'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) 
            {
              // output data of each row
              while($row = $result->fetch_assoc()) 
              {
                $writer = strip_tags($row["name"]);
              }
            } 
//----------------------
            $sql = "INSERT INTO `review` (`id`, `pahoss_parking_id`, `text`, `writer`, `rating`) VALUES (NULL, '$pahoss_parking_id', '$text', '$writer', '$rate');";
            if ($conn->query($sql) === TRUE) {
              echo "Your review record successfully<br><h4 style='color:green;'>Thank You for Feedback</h4>";
              ?>
              <div style="width: 100%; float: left;text-align: center;">
                <button onclick="window.location='my_booking_list.php'" id="more" >Write  more review for other parking place</button>
              </div>              
              <?php

            } else {
              echo "Error: " . $sql . "<br>" . $conn->error;
            }
          }
        ?>

        </div>
      </div>
    </main>
    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <!-- Google analytics script-->
    <script type="text/javascript">
      if(document.location.hostname == 'pratikborsadiya.in') {
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
        ga('create', 'UA-72504830-1', 'auto');
        ga('send', 'pageview');
      }
    </script>
  </body>
</html>
<?php
}
else
{
  echo '<script>{location.replace("login.php")}</script>';
}
?>
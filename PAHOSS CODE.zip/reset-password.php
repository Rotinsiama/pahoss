<?php
header("X-Frame-Options:DENY");
header_remove("Server");
header_remove("X-Powered-By");
header_remove("X-Frame-Options");
include 'conn.php';
include 'log.php';
if (isset($_POST['reset-password-submit'])) 
{
	$selector = $_POST['selector'];	
	$token = $_POST['token'];
	$password1 = $_POST['password1'];
	$password2 = $_POST['password2'];

	if(empty($password1) || empty($password2))
	{
		echo '<script>{alert("Enter New Password...");}</script>';
			?>
				<script>
					function goBack() 
					{
					  	window.history.back();
					}
					goBack();
				</script>
			<?php
		exit();
	}
	elseif ($password1!=$password2) 
	{
		echo '<script>{alert("Enter Password are not Match...");}</script>';
			?>
				<script>
					function goBack() 
					{
					  	window.history.back();
					}
					goBack();
				</script>
			<?php
		exit();
	}

	$currentDate = date("U");
	
	$stmt = $conn->prepare("SELECT token, email FROM `pwdreset` WHERE selector=? AND expires>=$currentDate;");
	$stmt->bind_param('s', $selector);
    $stmt->execute();
    $stmt->bind_result($dbtoken, $dbemail);// get the database output
    $stmt->store_result();
    if($stmt->num_rows == 1)  //To check if the row exists
    {
		// output data of each row
		if($stmt->fetch()) 
		{
			// Checking he/she give old password...
			$email = $dbemail;
			$stmt = $conn->prepare("SELECT salt  FROM users  WHERE email =? LIMIT 1;");
			$stmt->bind_param('s', $email);
	    	$stmt->execute();
	    	$stmt->bind_result($dbsalt);// get the database output
	    	$stmt->store_result();
	    	if($stmt->num_rows == 1)  //To check if the row exists
	        {
			    // output data of each row
			    if($stmt->fetch()) 
				{
					$pas = $password1.$dbsalt;
	  			    $newpwdhash  = hash('sha256', $pas);

					$stmt = $conn->prepare("SELECT id, mobile, email, password FROM users  WHERE email =? AND password = ? LIMIT 1;");
					$stmt->bind_param('ss', $email, $newpwdhash);
			    	$stmt->execute();
			    	$stmt->bind_result($id, $mobile_no, $email, $password);// get the database output
			    	$stmt->store_result();
			    	if($stmt->num_rows == 1)  //To check if the row exists
			        {
					    // output data of each row
					    if($stmt->fetch()) 
						{
						    logger('reset-password.php;'.$dbemail.' try to change his password with his all password. it fail.');
					    	echo "<script type='text/javascript'>alert('Try with another stronger password!')</script>";
							?>
								<script>
									function goBack() 
									{
									  	window.history.back();
									}
									goBack();
								</script>
							<?php
							exit();	
						}
					} 	
				}
			}
			else 
			{
			    logger('reset-password.php Someone try to reset password using Invalid/Expired Link and it Fail');
			    echo "<script type='text/javascript'>alert('Invalid link OR Token expired...')</script>";
			   	echo '<script>{location.replace("login.php")}</script>';
			   	exit();
			}
			// End of checking ther old password..

			$tokenn =hex2bin($token);
        	$tokencheck = password_verify($tokenn, $dbtoken);
        	if($tokencheck === false)
        	{
	            logger('reset-password.php Someone try to reset password using Invalid/Expired Link and it Fail');
				echo '<script>{alert("Invalid link OR Token expired...");}</script>';
				echo '<script>{location.replace("login.php")}</script>';
				exit();
        	}
        	elseif($tokencheck === true)
        	{
			    $sql = "UPDATE `users` SET `password` = ?, `salt` = ? WHERE `email` = ?;";
			    $stmt = mysqli_stmt_init($conn);
				if (!mysqli_stmt_prepare($stmt,$sql)) 
				{
				    logger('reset-password.php;'.$dbemail.' try to change his/her password due to server respnse slow it fail.');
					echo '<script>{alert("Something went wrong we could not update your password. Try Again...");}</script>';
					echo '<script>{location.replace("login.php")}</script>';
					exit();
				}
				else
				{

                    $length_of_string = 100;
                    $salt = substr(bin2hex(random_bytes($length_of_string)), 0, $length_of_string);
                    $pas = $password1.$salt;
                  	$newpwdhash  = hash('sha256', $pas);

					//$newpwdhash = md5($password1);
					mysqli_stmt_bind_param($stmt, 'sss',$newpwdhash, $salt, $dbemail);
					mysqli_stmt_execute($stmt);

					$sql = "DELETE FROM pwdreset WHERE email=?";
					$stmt = mysqli_stmt_init($conn);
					if (!mysqli_stmt_prepare($stmt,$sql)) 
					{
	                    logger('reset-password.php;'.$dbemail.' change his/her password successfully');
						echo '<script>{alert("Succecfully change Password!!");}</script>';
						echo '<script>{location.replace("login.php")}</script>';
						exit();
					}
					else
				    {
			            mysqli_stmt_bind_param($stmt,"s", $dbemail);
			            mysqli_stmt_execute($stmt);
	                    logger('reset-password.php;'.$dbemail.' change his/her password successfully');
						echo '<script>{alert("Succecfully change Password!!");}</script>';
						echo '<script>{location.replace("login.php")}</script>';
						exit();
			        }
						
				}
        	}
		}
	}
	else 
	{
	    logger('reset-password.php Someone try to reset password using Invalid/Expired Link and it Fail');
	    echo "<script type='text/javascript'>alert('Expired link or Invalid Link!! Try Again')</script>";
		echo '<script>{location.replace("login.php")}</script>';
		exit();
	}
}
else
{
	header("Location:login.php");
	exit();
}
<?php
error_reporting(0);
$errors ='';
if (isset($_POST['upload'])) 
{
    include '../conn.php';
	$captcha_id = $_POST['captcha_id'];
	$captcha = $_POST['captcha'];
	$i = 1;
	//Checking captcha
	$sql1 = "SELECT * FROM `captcha_table` ORDER BY id DESC LIMIT 3;";
	$result = mysqli_query($conn, $sql1);
	if (mysqli_num_rows($result) > 0) 
	{
	    // output data of each row
	    while($row = mysqli_fetch_assoc($result)) 
	    {
	        $captcha_id_db[$i] = $row["captcha_id"];
	        $captcha_db[$i] = $row["captcha"];
	      	$i++;
	      }
	} 
    else 
    {
	?>
	    <script type="text/javascript">
	        location.replace("login.php");
	    </script>
    <?php
    exit();
    }
    


	if($captcha==$captcha_db[2] and $captcha_id_db[2]==$captcha_id)
    {
	   	$del = "DELETE FROM `captcha_table` WHERE `captcha_table`.`captcha_id` = '$captcha_id_db[3]';";
	   	if ($conn->query($del) === TRUE) 
	   	{
			  //echo "Record deleted successfully";
		} 
		
        $userEmail = $_POST["email"];
        $selector = bin2hex(random_bytes(8));
        $token = random_bytes(32);
        $hashedToken = password_hash($token, PASSWORD_DEFAULT);
        $url =  "https://pahoss.000webhostapp.com/create-new-account.php?3ce6a0e=".$selector."&2d1807ff4=".bin2hex($token);
        $expires = date("U")+1800;

        // Checking email is registered or not....
        $sql = "SELECT * FROM users  WHERE email = '$userEmail' ";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) 
        {
            echo "<script type='text/javascript'>alert('Give email is Already Register')</script>";
            echo '<script>{location.replace("../login.php?error=Email given registered.")}</script>';
            exit();                
        }
        else
        {


            // If the email is register we can procded....
            // Delete first if there is token with the mail id match...
            $sql = "DELETE FROM newuser WHERE email=?";
            $stmt = mysqli_stmt_init($conn);
            if (!mysqli_stmt_prepare($stmt, $sql)) 
            {
                // Do nothing event if there is nothing to delete...
            }
            else
            {
                mysqli_stmt_bind_param($stmt,"s", $userEmail);
                mysqli_stmt_execute($stmt);
            }
            // Inset new token for reset password with expire time...
            $sql = "INSERT INTO `newuser` (`id`, `email`, `selector`, `token`, `expires`) VALUES (NULL, ?, '$selector', '$hashedToken', '$expires');";
            $stmt = mysqli_stmt_init($conn);
            if (!mysqli_stmt_prepare($stmt, $sql)) 
            {
                echo "<script type='text/javascript'>alert('Something wrong...!')</script>";
                echo '<script>{location.replace("../login.php")}</script>';
                exit();
            }
            else
            {
                mysqli_stmt_bind_param($stmt,"s", $userEmail);
                mysqli_stmt_execute($stmt);
    
                    // SENDING EMAIL...
                    $email=$_POST['email'];
                    require 'phpmailer/PHPMailerAutoload.php';
                    $mail = new PHPMailer;
                    //smtp settings
                    $mail->isSMTP(); // send as HTML
                    $mail->Host = "smtp-relay.sendinblue.com"; // SMTP servers
                    $mail->SMTPAuth = true; // turn on SMTP authentication
                    $mail->Username = "rotinsiamazadeng@gmail.com"; // Your mail
                    $mail->Password = 'DURxSfTsOtXgBN0Y'; // Your password mail
                    $mail->Port = 587; //specify SMTP Port
                    $mail->SMTPSecure = 'tls';                               
                    $mail->setFrom('pahoss@gmail.com','PAHOSS New User');
                    $mail->addAddress($email); // Your mail
                    $mail->addReplyTo('pahoss@gmail.com','PAHOSS');
                    $mail->isHTML(true);
                    $mail->Subject='Activate Account';
                    $code= rand(100,999);
                    mail($userEmail, "Send Code", $message);
                    $mail->Body= $message="<p>Well came to City Area Parking PAHOSS<p><br>Click the given link to Activate your Account.<br><a href=".$url.">".$url."</a>";
                    $mail->send();
                    
                    if (!$mail->send()) 
                    {
                        $sql = "DELETE FROM pwdreset WHERE email=?";
                        $stmt = mysqli_stmt_init($conn);
                        if (!mysqli_stmt_prepare($stmt, $sql)) 
                        {
                        // Do nothing event if there is nothing to delete...
                        }
                        else
                        {
                            mysqli_stmt_bind_param($stmt,"s", $userEmail);
                            mysqli_stmt_execute($stmt);
                         }
                        echo "<script type='text/javascript'>alert('Message could not be sent!')</script>";
                        echo '<script>{location.replace("../login.php")}</script>';
                        exit();
                    } 
                    else 
                    {
                    echo "<script type='text/javascript'>alert('Check Your Mail..')</script>";
                    echo '<script>{location.replace("../login.php")}</script>';
                    exit();
                    }
            }
        }   
        mysqli_stmt_close($stmt);
        mysqli_close($conn);
    }
    else
    {
        echo "<script type='text/javascript'>alert('No Match Captcha!')</script>";
        echo '<script>{location.replace("../login.php")}</script>';
	} 
}
else
{
    header("location:../login.php");
    exit();
}

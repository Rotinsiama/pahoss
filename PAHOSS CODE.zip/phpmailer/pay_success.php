<?php
error_reporting(0);
$errors ='';
function success($email)                    
{    

                      // SENDING EMAIL...
                    require 'phpmailer/PHPMailerAutoload.php';
                    $mail = new PHPMailer;
                    //smtp settings
                    $mail->isSMTP(); // send as HTML
                    $mail->Host = "smtp-relay.sendinblue.com"; // SMTP servers
                    $mail->SMTPAuth = true; // turn on SMTP authentication
                    $mail->Username = "rotinsiamazadeng@gmail.com"; // Your mail
                    $mail->Password = 'DURxSfTsOtXgBN0Y'; // Your password mail
                    $mail->Port = 587; //specify SMTP Port
                    $mail->SMTPSecure = 'tls';                               
                    $mail->setFrom('pahoss@gmail.com','PAHOSS');
                    $mail->addAddress($email); // Your mail
                    $mail->addReplyTo('pahoss@gmail.com','PAHOSS');
                    $mail->isHTML(true);
                    $mail->Subject='Success Payment';
                    $code= rand(100,999);
                    mail($userEmail, "Thank You", $message);
                    $mail->Body= $message="<h1>Thank You for Using PAHOSS Service.</h1>";
                    $mail->send();
                    
                    if (!$mail->send()) 
                    {
      
                        echo "<script type='text/javascript'>alert('Payment are success, we have problem sending Email to your address!!;')</script>";
                        echo '<script>{location.replace("index.php")}</script>';
                        exit();
                    } 
                    else 
                    {
                    echo "<script type='text/javascript'>alert('Thank You for using PAHOSS Service.')</script>";
                    echo '<script>{location.replace("index.php")}</script>';
                    exit();
                    }
}

  


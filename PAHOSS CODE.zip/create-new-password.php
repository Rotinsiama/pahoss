<?php 
header("X-Frame-Options:DENY");
header_remove("Server");
header_remove("X-Powered-By");
header_remove("X-Frame-Options");
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Create New Password</title>
    <link rel="icon" href="favicon.png" type="image/gif" />
  </head>
  <script src="js/MD5.js"></script>
  <script>



      function encrypt()
    {
      var pass1=document.getElementById('password1').value;
      var pass2=document.getElementById('password2').value;
      var hash1 = MD5(pass1);
      var hash2 = MD5(pass2);
      
      document.getElementById('password1').value=hash1;
      document.getElementById('password2').value=hash2;
      return true;
    } 
  </script>
<style type="text/css">
  body
  {
      -webkit-touch-callout: none; /* iOS Safari */ 
      -webkit-user-select: none; /* Safari */ 
       -khtml-user-select: none; /* Konqueror HTML */ 
         -moz-user-select: none; /* Firefox */ 
          -ms-user-select: none; /* Internet Explorer/Edge */ 
              user-select: none; /* Non-prefixed version, currently 
                                    supported by Chrome and Opera */      
  }  

    .captcha
    {
      width:70px;
      height: 25px; 
      background-image:url(images/cat.jpg); 
      font-size:20px; 
      border: 1px solid;
      color: gray;
    }
    .color
    {
      color:#FF0000;
    }
  </style>
  <body>
    <section class="material-half-bg">
      <div class="cover"></div>
    </section>
    <section class="login-content">
      <div class="logo">
        <h1>DEPARTMENT OF LABOUR & EMPLOYEMENT</h1>
      </div>
      <?php

      $selector = "";
      $token = "";
      if(isset($_GET['3ce6a0e']) && isset($_GET['2d1807ff4']))
      {
        $selector = $_GET['3ce6a0e'];
        $token = $_GET['2d1807ff4'];
      }
     
      if(empty($selector) || empty($token))
      {
        ?>
        <div style=" height: 200px; width: 300px; background-color: white; text-align: center; padding: 50px;">
          <h4>ERROR:</h4>
          <hr>
          <p>Invalid URL</p>
          
          <a href="index.php">Login</a>
          <br>
        </div>
        <?php
      }
      else
      {
        if (ctype_xdigit($selector))
        {
          ?>
          <div class="login-box">
            <form class="login-form" action="reset-password.php" method="post" name="form1">
              <input type="hidden" name="selector" value="<?php echo $selector?>">
              <input type="hidden" name="token" value="<?php echo $token?>">
              <br>
              <h4 class="login-head"><i class="fa fa-lg fa-fw fa-lock"></i>Create New Password</h4>
              <br>
              <div class="form-group">
                <div class="form-group">
                <input class="form-control" type="password" id="password1" name="password1" placeholder="Password" onpaste="return false" pattern="(?=.*\d)(?=.*[a-z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters">
              </div>
              <div class="form-group">
                <input class="form-control" type="password" id="password2" name="password2" placeholder="Confarm-Password" onpaste="return false" pattern="(?=.*\d)(?=.*[a-z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters">
              </div>
              </div>
              <div class="form-group btn-container">
                <input type="Submit" name="reset-password-submit" class="btn btn-primary btn-block" value="Submit" onclick="encrypt()">
              </div>
            </form>
          </div>
          <?php
        }
        else
        {
          ?>
        <div style=" height: 200px; width: 300px; background-color: white; text-align: center; padding: 50px;">
          <h4>ERROR:</h4>
          <hr>
          <p>Invalid Link</p>
    
          <a href="index.php">Login</a>
          <br>
        </div>
        <?php
        }

      }

      ?>
    </section>
    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
  </body>
</html>
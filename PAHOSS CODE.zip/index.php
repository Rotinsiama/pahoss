<?php
header("X-Frame-Options:DENY");
header_remove("Server");
header_remove("X-Powered-By");
header_remove("X-Frame-Options");
session_start();
if(isset($_SESSION['thuruk_user']))
{
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Pahoss</title>
    <link rel="icon" href="favicon.png" type="image/gif" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
<script type="text/javascript">
  var id = sessionStorage.getItem("tab-id");
  if (id==null) 
  {
    //location.replace("https://www.google.com/")
  }

    function showPosition() 
    {
      if(navigator.geolocation) 
      {
            navigator.geolocation.getCurrentPosition(function(position) {
                var latitude =  position.coords.latitude;
                //document.getElementById("result").innerHTML = positionInfo;
                var longitude =  position.coords.longitude;
                //document.getElementById("result1").innerHTML = positionInfo;
              var link = "index.php?lat="+latitude+"&long="+longitude;
              location.replace(link);


            });
        } else {
            alert("Sorry, your browser does not support HTML5 geolocation.");
        }
        varr = "a"
    }
</script>
<style type="text/css">
  body
  {
      -webkit-touch-callout: none; /* iOS Safari */ 
      -webkit-user-select: none; /* Safari */ 
       -khtml-user-select: none; /* Konqueror HTML */ 
         -moz-user-select: none; /* Firefox */ 
          -ms-user-select: none; /* Internet Explorer/Edge */ 
              user-select: none; /* Non-prefixed version, currently 
                                    supported by Chrome and Opera */      
  }  
    .near
    {
      width: 47%;
      float: left;
      padding: 20px 0px;
      background-color: white;
      border: 1px solid ;
      margin: 10px 5px;
      border-radius: 10px;
      text-align: left;
      display: inline-flex;
      font-weight: bolder;
      display: inline-flex;
      display: none;
    }
    .near:hover
    {
      background-color: lightgray;
      color: #080708;
      border: 1px solid white;
    }
    @media only screen and (max-width: 700px)
    {
      .near
      {
        width: 100%;
        margin: 10px 0px;
      }
    }
    .center 
    {
      margin: auto;
      width: 50%;
      border: 1px solid #73AD21;
      padding:30px 10px;
      background-color:  #cc00cc;
    }
    .center:hover
    {
      background-color: white;
      border: 1px solid white; 
    }
    @media only screen and (max-width: 700px)
    {
      .center
      {
        width: 100%;
      }
    }
  </style>
  <body  class="app sidebar-mini">

    <?php include "app-menu.php";?>
    
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-edit"></i>SEARCH PARKING SLOT NEAR FROM HERE</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="home.php">Home</a></li>
        </ul>
      </div>
      <?php
      function twopoints_on_earth($latitudeFrom, $longitudeFrom, $latitudeTo, $longitudeTo) 
      { 
        $long1 = deg2rad($longitudeFrom); 
        $long2 = deg2rad($longitudeTo); 
        $lat1 = deg2rad($latitudeFrom); 
        $lat2 = deg2rad($latitudeTo); 
          
        //Haversine Formula 
        $dlong = $long2 - $long1; 
        $dlati = $lat2 - $lat1; 
          
        $val = pow(sin($dlati/2),2)+cos($lat1)*cos($lat2)*pow(sin($dlong/2),2); 
          
        $res = 2 * asin(sqrt($val)); 
          
        $radius = 3958.756; 
          
        return ($res*$radius); 
      }
      $num = 0;
      if (isset($_GET['lat'])) 
      { 
        $latitudeFrom = $_GET['lat'];
        $longitudeFrom = $_GET['long'];
        echo "<style>.near{ display:block;}</style>";

              include 'conn.php';
              static $j=0;
              $id = array();
              $owner_name = array();
              $contact = array();
              $address = array();
              $gps_lat = array();
              $gps_long = array();
              $distance = array();
              $temp = array();
              $sql = "SELECT * FROM `parking_slot`;";
              $result = $conn->query($sql);
              if ($result->num_rows > 0) 
              {
                // output data of each row
                while($row = $result->fetch_assoc()) 
                {
                  $id[$j] = strip_tags($row["id"]);
                  $owner_name[$j] = strip_tags($row["owner_name"]);
                  $contact[$j] = strip_tags($row["contact"]);
                  $address[$j] = strip_tags($row["address"]);
                  $gps_lat[$j] = strip_tags($row["gps_lat"]);
                  $gps_long[$j] = strip_tags($row["gps_long"]);
                  $j++;
                }
                          
                $num =count($id);
                for ($i=0; $i < $num ; $i++) 
                { 
                    $distance[$i] = twopoints_on_earth($latitudeFrom,$longitudeFrom,$gps_lat[$i],$gps_long[$i])*1609.34;
                  //echo $distance[$i]."--".$owner_name[$i]."<br><br>";
                  $temp[$i] = $distance[$i];
                }
            }
            sort($distance);
            $new = array();
            $g = 0;
            for ($k=0; $k < $num; $k++)
            { 
              for ($l=0; $l <$num ; $l++) 
              { 
                 if($distance[$k] == $temp[$l])
                 {
                    $new_id[$g] = strip_tags($id[$l]);
                    $new_name[$g] = strip_tags($owner_name[$l]); 
                    $new_contact[$g] = strip_tags($contact[$l]); 
                    $new_address[$g] = strip_tags($address[$l]); 
                    $g++;
                 }
              }
            }
          }
        ?>
      <div style="width: 100%;float: left;text-align: center;background-color: lightgray;padding: 20px;">
        <div id="center" onclick="showPosition();" class="center" style="font-size: 25px; margin-bottom: 50px; margin-top: 50px; border-radius: 5px; ">
              Click Search Parking Slot Near me.<i class="far fa-car-building" style="font-size: 50px;t"></i>
        </div>
        <hr>
        <div style="float: left;text-align: center;color: gray;">
         <?php 
            for ($z=0; $z < $num ; $z++) 
            { 
           
         ?> 
         <div class="near" id="near"   onclick="window.location='check.php?parking_slot_id=<?php echo $new_id[$z];?>&mylat=<?php echo $latitudeFrom?>&mylong=<?php echo $longitudeFrom?>'">
          <div style="display: inline-flex;">
          <?php echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<h5>".($z+1)."</h5>.<span style='padding-left:5px; color:#00cc00;'>".number_format($distance[$z]) ."&nbsp; Meters From your location</span>,&nbsp;&nbsp;".$new_name[$z].",&nbsp;&nbsp;".$new_address[$z];?> 
         </div>
         </div>
        <?php }?>
          <div style="width: 100%; ">
          </div>
        </div>
      </div>
    </main>
    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <!-- Google analytics script-->
    <script type="text/javascript">
      if(document.location.hostname == 'pratikborsadiya.in') {
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
        ga('create', 'UA-72504830-1', 'auto');
        ga('send', 'pageview');
      }
    </script>
  </body>
</html>
<?php
}
else
{
  echo '<script>{location.replace("login.php")}</script>';
}
?>
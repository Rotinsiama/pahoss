<?php
header("X-Frame-Options:DENY");
header_remove("Server");
header_remove("X-Powered-By");
header_remove("X-Frame-Options");
session_start();
if(isset($_SESSION['thuruk_user']))
{
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Pahoss</title>
    <link rel="icon" href="favicon.png" type="image/gif" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
<script type="text/javascript">
	var id = sessionStorage.getItem("tab-id");
	if (id==null) 
	{
		//location.replace("https://www.google.com/")
	}
</script> 
<style type="text/css">
  body
  {
    background-color: lightgray;
      -webkit-touch-callout: none; /* iOS Safari */ 
      -webkit-user-select: none; /* Safari */ 
       -khtml-user-select: none; /* Konqueror HTML */ 
         -moz-user-select: none; /* Firefox */ 
          -ms-user-select: none; /* Internet Explorer/Edge */ 
              user-select: none; /* Non-prefixed version, currently 
                                    supported by Chrome and Opera */      
  }  
</style>
  <body class="app sidebar-mini">

    <?php include "app-menu.php";?>
    
    <main class="app-content" style="background-color: lightgray;">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-edit"></i>My booking List</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="home.php">Home</a></li>
        </ul>
      </div>
      <div style="width: 100%;float: left;text-align: center;">
        <div style="width: 100%;float: left;text-align: center;color: gray; padding-bottom: 20px;">
          <?php

            include 'conn.php';
            static $i = 0;
            $id = array();
            $customer_id = array();
            $customer_name = array();
            $pahoss_parking_id = array();
            $owner_name = array();
            $slot_id = array();
            $booking_time = array();
            $expire_time = array();
            $payment_id = array();
            $amount = array();
            $customer_idd = $_SESSION['thuruk_user'];                     
                                
            $sql = "SELECT * FROM `booking` WHERE customer_id = '$customer_idd';";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) 
              {
                // output data of each row
                while($row = $result->fetch_assoc()) 
                {
                  $id[$i] = strip_tags($row['id']);
                  $customer_id[$i] = strip_tags($row['customer_id']);
                  $customer_name[$i] = strip_tags($row['customer_name']);
                  $pahoss_parking_id[$i] = strip_tags($row['pahoss_parking_id']);
                  $owner_name[$i] = strip_tags($row['owner_name']);
                  $slot_id[$i] = strip_tags($row['slot_id']);
                  $booking_time[$i] = strip_tags($row['booking_time']);
                  $expire_time[$i] = strip_tags($row['expire_time']);
                  $payment_id[$i] = strip_tags($row['payment_id']);
                  $amount[$i] = strip_tags($row['amount']);
                  $cancel[$i] = strip_tags($row['cancel']);
                  $i++;
                }
                $num = count($id);
            for ($k=0; $k < $num; $k++) 
            { 
          
          ?>
          <div style="width: 100%; float: left; margin-top: 20px; background-color: white; padding: 10px 0px;">
            <div style="width: 5%; float: left; border-right: 1px solid;">
              <?php echo ($k+1);?>
            </div>
            <div style="width: 25%; float: left;">
              <?php echo $owner_name[$k]; ?>
              <?php
              if ($cancel[$k] == 1) 
              {
                echo "<br><span style='color:red;'>You cancel Booking.</span>";
              }
              ?>
            </div>                       
            <div style="width: 30%; float: left; border-right: 1px solid; border-left: 1px solid; overflow-wrap: break-word;   padding: 2px;">
                <?php echo 'Duration:'.$booking_time[$k]." to ".$expire_time[$k] ?>
            </div>            
            <div style="width: 12%; float: left;">
                  Rs.<?php echo $amount[$k]; ?>
            </div>            
            <div style="width: 18%; float: left;">
              <?php
                if (date('Y-m-d') > $expire_time[$k]|| $cancel[$k] == 1)
                {
                ?>
                    <button style="border: none;border-radius: 5px; padding: 10px;margin-top: 2px; background-color:gray;" onclick="window.location='review.php?pahoss_parking_id=<?php echo $pahoss_parking_id[$k];?>';">REVIEW</button>                
                <?php
                }
                else
                 {
                 ?>
                    <button style="border: none;border-radius: 5px; padding: 10px;margin-top: 2px; background-color:red;" onclick="window.location='cancel_booking.php?booking_id=<?php echo $id[$k];?>&slot_id=<?php echo $slot_id[$k]?>&pahoss_parking_id=<?php echo $pahoss_parking_id[$k]?>';">CANCEL</button>
                  <?php
                 }
              ?>
            </div>
          </div>
          <?php
            }
          }
          else
          {
            ?>
            <div style="width: 100%; float: left; color: black; font-size: 20px;">
              You don't have any booking.
            </div>
            <?php
          }
          ?>
        </div>
      </div>
    </main>
    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <!-- Google analytics script-->
    <script type="text/javascript">
      if(document.location.hostname == 'pratikborsadiya.in') {
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
        ga('create', 'UA-72504830-1', 'auto');
        ga('send', 'pageview');
      }
    </script>
  </body>
</html>
<?php
}
else
{
  echo '<script>{location.replace("login.php")}</script>';
}
?>
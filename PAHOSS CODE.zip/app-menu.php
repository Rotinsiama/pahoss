      <?php
        include 'conn.php';
        $sql = "SELECT * FROM `users`;";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) 
        {
          // output data of each row
          while($row = $result->fetch_assoc()) 
          {
            $name = $row["name"];
          }
        }
      ?>    <!-- Navbar-->
     <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <header class="app-header"><a class="app-header__logo" href="index.php">PAHOSS</a>
      <!-- Sidebar toggle button--><a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
      <!-- Navbar Right Menu-->
      <ul class="app-nav">
        <!-- User Menu-->
        <li class="dropdown"><a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu"><i class="fa fa-user fa-lg"></i></a>
          <ul class="dropdown-menu settings-menu dropdown-menu-right">
            <li><a class="dropdown-item" href="page-user.php"><i class="fa fa-user fa-lg"></i> Profile</a></li>
            <li><a class="dropdown-item" href="logout.php"><i class="fa fa-sign-out fa-lg"></i> Logout</a></li>
          </ul>
        </li>
      </ul>
    </header>
    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">
      <div class="app-sidebar__user"><img class="app-sidebar__user-avatar" src="images/avatar1.png" alt="User Image">
        <div>
          <p class="app-sidebar__user-name"><?php echo $name;?></p>
          <p class="app-sidebar__user-designation">PAHOSS</p>
        </div>
      </div>      
      <ul class="app-menu">
        <li><a class="app-menu__item" href="home.php"><i class="app-menu__icon fa fa-home" style="font-size: 20px;"></i><span class="app-menu__label">HOME</span></a></li>
        
        <li><a class="app-menu__item" href="index.php"><i class="app-menu__icon fa fa-search"></i><span class="app-menu__label">SEARCH PARKING SLOT</span></a></li>        
        <li><a class="app-menu__item" href="pashoss_parking_list.php"><i class="app-menu__icon fa fa-car-building" style="font-size: 20px;"></i><span class="app-menu__label">PAHOSS PARKING LIST</span></a></li>

        <li><a class="app-menu__item " href="my_booking_list.php"><i class="app-menu__icon fa fa-car" style="font-size: 25px;"></i><span class="app-menu__label">MY PARKING SLOT</span></a></li>
      </ul>
    </aside>
    <?php include 'conn.php';?>
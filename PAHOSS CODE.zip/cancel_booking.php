<?php
header("X-Frame-Options:DENY");
header_remove("Server");
header_remove("X-Powered-By");
header_remove("X-Frame-Options");
session_start();
if(isset($_SESSION['thuruk_user']))
{
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Pahoss</title>
    <link rel="icon" href="favicon.png" type="image/gif" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
<script type="text/javascript">
	var id = sessionStorage.getItem("tab-id");
	if (id==null) 
	{
		//location.replace("https://www.google.com/")
	}
</script>
<style type="text/css">
  body
  {
      -webkit-touch-callout: none; /* iOS Safari */ 
      -webkit-user-select: none; /* Safari */ 
       -khtml-user-select: none; /* Konqueror HTML */ 
         -moz-user-select: none; /* Firefox */ 
          -ms-user-select: none; /* Internet Explorer/Edge */ 
              user-select: none; /* Non-prefixed version, currently 
                                    supported by Chrome and Opera */      
  }  
</style>
  <body class="app sidebar-mini">

    <?php include "app-menu.php";?>
    
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-edit"></i>CANCEL BOOKING</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="home.php">home</a></li>
        </ul>
      </div>
      <div style="width: 100%;float: left;text-align: center;background-color: lightgray;padding: 20px;">
        <div style="width: 100%;float: left;text-align: center;color: gray; padding-bottom: 20px;">
          <?php
            include 'conn.php';
            $booking_id = strip_tags($_GET['booking_id']); 
            $slot_id = strip_tags($_GET['slot_id']);
            $pahoss_parking_id = strip_tags($_GET['pahoss_parking_id']);

            $sql = "UPDATE booking SET cancel ='1' WHERE id = $booking_id";
            if ($conn->query($sql) === TRUE) 
            {
              $sql1 = "UPDATE `slot` SET `available_time` = '0', `availability` = 'yes' WHERE `slot`.`id` = $slot_id;";
              if ($conn->query($sql1) === TRUE) 
              {
                echo "<h4 style='color:green;'>Successfully cancel booking</h4><hr>";
                ?>
                <div style="width: 100%; float: left;text-align: center; padding: 30px; margin: 20px 0px;">
                  <button style="width: 50%; text-align: center; padding: 10px; border: none; background-color: gray; border-radius: 6px;" onclick="window.location='index.php';">Find other parking place.</button>
                </div>
                <div style="width: 100%; float: left;text-align: center; padding: 30px; margin: 20px 0px;">
                  <button style="width: 50%; text-align: center; padding: 10px; border: none; background-color: gray; border-radius: 6px;" onclick="window.location='review.php?pahoss_parking_id=<?php echo $pahoss_parking_id; ?>';">WRITE REVIEW</button>
                </div>                
                <?php
              } 
              else 
              {
                echo "Error updating record: " . $conn->error;
              }
            } 
            else 
            {
              echo "Error updating record: " . $conn->error;
            }

          ?>
        </div>
      </div>
    </main>
    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <!-- Google analytics script-->
    <script type="text/javascript">
      if(document.location.hostname == 'pratikborsadiya.in') {
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
        ga('create', 'UA-72504830-1', 'auto');
        ga('send', 'pageview');
      }
    </script>
  </body>
</html>
<?php
}
else
{
  echo '<script>{location.replace("login.php")}</script>';
}
?>
<?php	
// Start the session
	session_start();
    header("X-Frame-Options:DENY");
    header_remove("Server");
    header_remove("X-Powered-By");
    header_remove("X-Frame-Options");
	include 'conn.php';
    include 'log.php';
	if(isset($_POST['login'])) 
	{

		$email = $_POST['email'];			
		$password = $_POST['password'];

		$captcha_id = $_POST['captcha_id'];
		$captcha = $_POST['captcha'];
		$i = 1;
		//Checking captcha
	    $sql1 = "SELECT * FROM `captcha_table` ORDER BY id DESC LIMIT 3;";
	    $result = mysqli_query($conn, $sql1);

	    if (mysqli_num_rows($result) > 0) 
	    {
	      // output data of each row
	      while($row = mysqli_fetch_assoc($result)) 
	      {
	        $captcha_id_db[$i] = $row["captcha_id"];
	        $captcha_db[$i] = $row["captcha"];
	      	$i++;
	      }
	    } 
	    else 
	    {
	    ?>
	      <script type="text/javascript">
	        location.replace("index.php");
	      </script>
	    <?php
	    exit();
	    }

	    if($captcha==$captcha_db[3] and $captcha_id_db[3]==$captcha_id)
	    {
	    	$del = "DELETE FROM `captcha_table` WHERE `captcha_table`.`captcha_id` = '$captcha_id_db[3]';";
	    	if ($conn->query($del) === TRUE) 
	    	{
			  //echo "Record deleted successfully";
			} 
			// fetching SALT from DB...
    		$stmt = $conn->prepare("SELECT salt, email  FROM admin_table  WHERE email =? LIMIT 1;");
    		$stmt->bind_param('s', $email);
        	$stmt->execute();
        	$stmt->bind_result($dbsalt, $dbemail);// get the database output
        	$stmt->store_result();
        	if($stmt->num_rows == 1)  //To check if the row exists
            {
    		    // output data of each row
    		    if($stmt->fetch()) 
    			{
    			    if(md5($email)==md5($dbemail))
    			    {
        				$pas = $password.$dbsalt;
          			    $newpwdhash  = hash('sha256', $pas);
                        
                        // Fetching and cheching match password and email----
        				$stmt = $conn->prepare("SELECT id, email FROM admin_table  WHERE email =? AND password = ? LIMIT 1;");
        				$stmt->bind_param('ss', $email, $newpwdhash);
        		    	$stmt->execute();
        		    	$stmt->bind_result($id, $email);// get the database output
        		    	$stmt->store_result();
        		    	if($stmt->num_rows == 1)  //To check if the row exists
        		        {
        				    // output data of each row
        				    if($stmt->fetch()) 
        					{
        					    // Set session variables
        					    $_SESSION["thuruk"] = $id;
        					    $_SESSION['loggedin_time'] = time(); 
                    					    
                                $token = substr(bin2hex(random_bytes(50)), 0, 50);
                                $_SESSION['token'] = $token;
                    
                                // Update user token 
                                $sql = "SELECT * FROM `user_token`;";
                                $result = $conn->query($sql);
        
                                if ($result->num_rows > 0) 
                                {
                                    $sql = "UPDATE `user_token` SET `token` = '$token' WHERE `user_token`.`id` = 1;";
                                    
                                    if (mysqli_query($conn, $sql)) 
                                    {
                                        logger('Login.php Login Attempted Successfull UserName= '.$email);
                                        echo '<script>{location.replace("home.php")}</script>';
                                        exit();
                                    } 
                                    else 
                                    {
                                        logger('Login.php Login Attempted Failed Name= '.$email);
                                        header('Location:index.php?error=ERROR: Invalid Email Or Password!');
                    				    exit();
                                    }                      
                                } 
                                else 
                                {
                                    
                                    $sql = "INSERT INTO `user_token` (`id`, `token`) VALUES (1, '$token');";
                                    
                                    if (mysqli_query($conn, $sql)) 
                                    {
                                        logger('Login.php Login Attempted Successfull UserName= '.$email);                                        
                                        echo '<script>{location.replace("home.php")}</script>';
                                        exit();
                                    } 
                                    else 
                                    {
                                        logger('Login.php Login Attempted Failed Name= '.$email);
                                        header('Location:index.php?error=ERROR: Invalid Email Or Password!');
                    				    exit();
                                    }
                                }
        					}
        				}
        				else 
        				{
                            logger('Login.php Login Attempted Failed Name= '.$email);
        				    header('Location:index.php?error=ERROR: Invalid Email Or Password!');
        				   	exit();
        				} 	
    			    }
    			    else
    			    {
                        logger('Login.php Login Attempted Failed Name= '.$email);
            		    header('Location:index.php?error=ERROR: Invalid Email Or Password!');
            		    exit();
    			    }
    			}
    		}
    		else 
    		{
                logger('Login.php Login Attempted Failed Name= '.$email);
    		    header('Location:index.php?error=ERROR: Invalid Email Or Password!');
    		    exit();
    		}
        }
	    else
	    {
            logger('Login.php Login Attempted Failed Name= '.$email.' Captcha not match');
			header('Location:index.php?error=Not Match Captcha!');
			exit();
	    }
	}
	else
	{
        logger('Login.php Login Attempted Failed: Someone try to login without userid or password');
		header('Location:index.php?error=ERROR: Request terminating...!');
		exit();
	}
?>
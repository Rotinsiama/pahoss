<?php
    header("X-Frame-Options:DENY");
    header_remove("Server");
    header_remove("X-Powered-By");
    header_remove("X-Frame-Options");
    include 'conn.php';
    $captcha = substr(bin2hex(random_bytes(8)), 0, 8);
    $captcha_id = substr(bin2hex(random_bytes(50)), 0, 50);
    $i = 1;
    $sql = "INSERT INTO `captcha_table` (`id`, `captcha_id`, `captcha`) VALUES (NULL, '$captcha_id', '$captcha');";
    if ($conn->query($sql) === TRUE) 
    {
        $sql1 = "SELECT * FROM `captcha_table` ORDER BY id DESC LIMIT 3;";
        $result = $conn->query($sql1);

        if ($result->num_rows > 0) 
        {
        // output data of each row
        while($row = $result->fetch_assoc()) 
        {
            $captcha_id_db[$i] = $row["captcha_id"];
            $captcha_db[$i] = $row["captcha"];
            $i++;
        }
    } 
    else 
    {
    ?>
      <script type="text/javascript">
        location.replace("index.php");
      </script>
    <?php
    exit();
    }
  } 
  else 
  {
    ?>
      <script type="text/javascript">
        location.replace("index.php");
      </script>
    <?php
    exit();
  }

?>
<!DOCTYPE html>
<html>
  <head>
    <link rel="icon" href="favicon.png" type="image/gif" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Login - Admin</title>
	<script type="text/javascript">
        var max = 99999999;
        var min = 10000000;
        sessionStorage_name = Math.floor(Math.random() * (max - min + 1) + min);
    	sessionStorage.setItem("tab-id", sessionStorage_name);
    	var id = sessionStorage.getItem("tab-id");
	</script>
  </head>
<script src="js/MD5.js"></script>
<script>
    function encrypt()
  {
    var pass=document.getElementById('password').value;
    var hash = MD5(pass);
    console.log(hash);
    document.getElementById('password').value=hash;
    return true;
  } 
</script>
  <style type="text/css">
    .captcha
    {
      width:70px;
      height: 25px; 
      background-image:url(images/cat.jpg); 
      font-size:20px; 
      border: 1px solid;
      color: gray;
    }
    .color
    {
      color:#FF0000;
    }
  </style>
  <body>
    <?php
	    $id="<script>document.writeln(id);</script>";
        $tab_id = $id;
    ?>
    <section class="material-half-bg">
      <div class="cover"></div>
    </section>
    <section class="login-content">
      <div class="logo">
        <h1>PAHOSS</h1>
      </div>
      <div class="login-box">
        <form class="login-form" action="login_action.php" method="post" name="form1">
          <h3 class="login-head"><i class="fa fa-lg fa-fw fa-user"></i>ADMIN</h3>
          <div class="form-group">
            <input class="form-control" type="emil" name="email" placeholder="Email" autofocus autocomplete="off" readonly 
onfocus="this.removeAttribute('readonly');">
          </div>
          <div class="form-group">
            <input class="form-control" type="password" name="password" placeholder="Password" id="password" onpaste="return false" pattern="(?=.*\d)(?=.*[a-z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" autocomplete="off" readonly 
onfocus="this.removeAttribute('readonly');">
          </div>
          <div class="form-group">
            <span id="error" class="color"></span>
            <table style="width: 100%; float: left; text-align: center;">
              <tr>
                <td>
                    <input type="hidden" name="tab_id" value="<?php echo $tab_id;?>">
                    <input type="hidden" name="captcha_id" value="<?php echo $captcha_id_db[3];?>">
                    <?php
                      $input_text = $captcha_db[3];
                      $width = (strlen($input_text)*9)+20;
                      $height = 30;
                      
                      $textImage = imagecreate($width, $height);
                      $color = imagecolorallocate($textImage, 0, 0, 0);
                      imagecolortransparent($textImage, $color);
                      imagestring($textImage, 5, 10, 5, $input_text, 0xFFFFFF);
                      
                      
                      // create background image layer
                      $background = imagecreatefromjpeg('images/captcha_bg.jpeg');
                      
                      // Merge background image and text image layers
                      imagecopymerge($background, $textImage, 15, 15, 0, 0, $width, $height, 100);
                      
                      
                      $output = imagecreatetruecolor($width, $height);
                      imagecopy($output, $background, 0, 0, 20, 13, $width, $height);
                      
                      
                      ob_start();
                      imagepng($output);
                      printf('<img id="output" src="data:image/png;base64,%s" />', base64_encode(ob_get_clean()));
                    ?>
                </td>
                <td>
                  <input type="text" name="captcha" id="chk" style="width: 100px;">
                </td>
                <td>
                  <input type="button" value="Referesh" onclick="window.location='index.php';"/>
                </td>
              </tr>
            </table>
          </div>
          <div style="width: 100%;float: left; height: 30px; color: red;" >
            <?php
              if (isset($_GET['error'])) 
              {
                echo $_GET['error'];
              }
            ?>
          </div>
          <div class="form-group btn-container">
            <input type="submit" value="Submit" onclick="encrypt()" name="login" class="btn btn-primary btn-block" >
          </div>
          <div class="form-group">
            <div class="utility">
              <div class="animated-checkbox">
              </div>
              <p class="semibold-text mb-2"><a href="#" data-toggle="flip">Forgot Password ?</a></p>
            </div>
          </div>
        </form>
        <form class="forget-form" action="phpmailer/index.php" method="POST" >
          <h6><i class="fa fa-lg fa-fw fa-lock"></i>Forgot Password ?</h6>
          <div class="form-group" style="padding-bottom:2px;">
            <input class="form-control" name="email" type="email" placeholder="Email" autocomplete="off" style=" border: none;border-bottom: 1px solid black; border-radius:0px;">
            <input class="form-control" name="mobile_no" type="number" placeholder="MobileNo" autocomplete="off" style=" border: none;border-bottom: 1px solid black; border-radius:0px;">
          </div>
          <div class="form-group">
            <span id="error" class="color"></span>
            <table style="width: 100%; float: left; text-align: center;">
              <tr>
                <td>
                    <input type="hidden" name="captcha_id" value="<?php echo $captcha_id_db[2];?>">
                    <?php
                      $input_text = $captcha_db[2];
                      $width = (strlen($input_text)*9)+20;
                      $height = 30;
                      
                      $textImage = imagecreate($width, $height);
                      $color = imagecolorallocate($textImage, 0, 0, 0);
                      imagecolortransparent($textImage, $color);
                      imagestring($textImage, 5, 10, 5, $input_text, 0xFFFFFF);
                      
                      
                      // create background image layer
                      $background = imagecreatefromjpeg('images/captcha_bg.jpeg');
                      
                      // Merge background image and text image layers
                      imagecopymerge($background, $textImage, 15, 15, 0, 0, $width, $height, 100);
                      
                      
                      $output = imagecreatetruecolor($width, $height);
                      imagecopy($output, $background, 0, 0, 20, 13, $width, $height);
                      
                      
                      ob_start();
                      imagepng($output);
                      printf('<img id="output" src="data:image/png;base64,%s" />', base64_encode(ob_get_clean()));
                    ?>
                </td>
                <td>
                  <input type="text" name="captcha" id="chk" style="width: 100px;">
                </td>

              </tr>
            </table>
          </div>
          <div style="width: 100%;float: left; height: 10px; color: red;" >
          </div>
          <div class="form-group btn-container">
            <button name="upload" value="upload" class="btn btn-primary btn-block"><i class="fa fa-unlock fa-lg fa-fw"></i>GET PASSWORD</button>
          </div>
          <div class="form-group mt-3">
            <p class="semibold-text mb-0"><a href="#" data-toggle="flip"><i class="fa fa-angle-left fa-fw"></i> Back to Login</a></p>
          </div>
        </form>
      </div>
    </section>
    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <script type="text/javascript">
      // Login Page Flipbox control
      $('.login-content [data-toggle="flip"]').click(function() {
        $('.login-box').toggleClass('flipped');
        return false;
      });
    </script>
  </body>
</html>
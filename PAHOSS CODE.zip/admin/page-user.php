<?php
header("X-Frame-Options:DENY");
header_remove("Server");
header_remove("X-Powered-By");
header_remove("X-Frame-Options");
include "check_token.php";
include("functions.php");
if(isset($_SESSION['thuruk']))
{
  if(isLoginSessionExpired()) 
  {
    header("Location:logout.php?session_expired=1");
  }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Admin</title>
    <link rel="icon" href="favicon.png" type="image/gif" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
      <script type="text/javascript">
      var id = sessionStorage.getItem("tab-id");
      if (id==null) 
      {
        location.replace("https://www.google.com/")
      }
    </script>
  <body class="app sidebar-mini">
    <script src="js/MD5.js"></script>
    <script>
        function encrypt()
      {
        var current_password =document.getElementById('current_password').value;
        var new_password =document.getElementById('new_password').value;
        var confirm_password =document.getElementById('confirm_password').value;
        var hash1 = MD5(current_password);
        var hash2 = MD5(new_password);
        var hash3 = MD5(confirm_password);
        
        document.getElementById('current_password').value=hash1;
        document.getElementById('new_password').value=hash2;
        document.getElementById('confirm_password').value=hash3;
        return true;
      } 
    </script>

    <?php include "app-menu.php";?>
    <main class="app-content">
      <div class="row user">
        <div class="col-md-12">
          <div class="tab-content">
            <div class="tab-pane active" id="user-timeline" style="width: 100%;float: left;text-align: center;background-color: white; padding: 50px;">
              <div style="width: 100%;float: left;text-align: center;">
                <h4>Change Password:</h4>
                <hr>
                <form action="change_password.php" method="post" style=" display: block;width: 100%;float: left;text-align: center; padding-top: 10px;">
                  <input type="hidden" name="id" value="<?php echo $_SESSION['thuruk']; ?>">
                  <input type="password" id="current_password" name="current_password" placeholder="Current Password" onpaste="return false" pattern="(?=.*\d)(?=.*[a-z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters"><br>
                  <br>
                  <input type="password" name="new_password" id="new_password" placeholder="New Password" onpaste="return false" pattern="(?=.*\d)(?=.*[a-z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters"><br>
                  <br>
                  <input type="password" name="confirm_password" id="confirm_password" placeholder="Confirm Password" onpaste="return false" pattern="(?=.*\d)(?=.*[a-z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters"><br>
                  <br>
                  <input type="submit" name="update" value="Update" onclick="encrypt()">
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <!-- Google analytics script-->
    <script type="text/javascript">
      if(document.location.hostname == 'pratikborsadiya.in') {
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
        ga('create', 'UA-72504830-1', 'auto');
        ga('send', 'pageview');
      }
    </script>
  </body>
</html>
<?php
}
else
{
  echo '<script>{location.replace("index.php")}</script>';
}
?>  
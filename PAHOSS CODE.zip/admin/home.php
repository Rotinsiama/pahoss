<?php
header("X-Frame-Options:DENY");
header_remove("Server");
header_remove("X-Powered-By");
header_remove("X-Frame-Options");
include "check_token.php";
include("functions.php");
if(isset($_SESSION['thuruk']))
{
  if(isLoginSessionExpired()) 
  {
    header("Location:logout.php?session_expired=1");
  }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>PAHOSS</title>
    <link rel="icon" href="favicon.png" type="image/gif" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
<script type="text/javascript">
  var id = sessionStorage.getItem("tab-id");
  if (id==null) 
  {
    location.replace("https://www.google.com/")
  }
</script>
<style type="text/css">
  #input
  {
    width: 18%;
    float: left;
    height: 30px;
    margin: 5px 10px; 
  }
  @media only screen and (max-width: 700px)
  {
    #input
    {
      width: 100%; 
      margin: 5px 0px;
    }    
  }
</style>
  <body class="app sidebar-mini">

    <?php include "app-menu.php";?>

    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-edit"></i>ADD NEW PARKING SLOT</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="home.php">HOME</a></li>
        </ul>
      </div>
      <?php
        include 'conn.php';
        static $j = 0;
        $id = array();
        $owner_name = array();
        $sql = "SELECT * FROM `parking_slot`;";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) 
        {
          // output data of each row
          while($row = $result->fetch_assoc()) 
          {
            $id[$j] = strip_tags($row["id"]);
            $owner_name[$j] = strip_tags($row["owner_name"]);
            $j++;
          }
        }
        $num = 0;
        $num = count($id);
      ?>
      <div style="margin-top: 50px;">
        <form action="up_slot.php" method="POST">
          <select id="input" name="parking_slot_id">
            <option value="0">Name of PAHOSS Parking </option>
            <?php 
            for ($i=0; $i < $num ; $i++) 
            { 
            ?>
            <option value='<?php echo $id[$i];?>' ><?php echo $owner_name[$i];?></option>
            <?php
            }
            ?>
          </select>
          <select id="input" name="floor">
            <option value="0">Select Floor</option>
            <option value="Ground Floor">Ground Floor</option>
            <option value="First Floor">First Floor</option>
            <option value="Second Floor">Second Floor</option>
            <option value="Third Floor">Third Floor</option>
          </select>
          <select id="input" name="vehicule_type">
            <option value="0">Slot Type</option>
            <option value="2">2 Wheeler Slot</option>
            <option value="4">4 Wheeler Slot</option>
          </select>
          <input id="input" type="number" name="slot_number" placeholder="Slot Number">
          <input id="input" type="number" name="price" placeholder="Price in per/day">
          <div style="width: 100%; float: left; text-align: center; margin-top: 30px;">
            <input type="submit" name="submit" value="Submit" style="padding:10px 30px;">
          </div>
        </form>
      </div>

    </main>
    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <!-- Google analytics script-->
    <script type="text/javascript">
      if(document.location.hostname == 'pratikborsadiya.in') {
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
        ga('create', 'UA-72504830-1', 'auto');
        ga('send', 'pageview');
      }
    </script>
  </body>
</html>
<?php
}
else
{
  echo '<script>{location.replace("index.php")}</script>';
}
?>
<?php
// Create connection
//$conn = mysqli_connect("localhost", "root", "", "pahoss");
$conn = mysqli_connect("localhost", "id16878935_pahoss_username", "Amaisnitor11#", "id16878935_pahoss_database");

/*if (!$conn) 
{
  die("Connection failed: " . mysqli_connect_error());
}
else
{
echo "Connected successfully";
}*/
?>
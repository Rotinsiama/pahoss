<?php
header("X-Frame-Options:DENY");
header_remove("Server");
header_remove("X-Powered-By");
header_remove("X-Frame-Options");
function isLoginSessionExpired() 
{
	$login_session_duration = 3600; 
	$current_time = time(); 
	if(isset($_SESSION['loggedin_time']) and isset($_SESSION["thuruk"]))
	{  
		if(((time() - $_SESSION['loggedin_time']) > $login_session_duration))
		{ 
			return true; 
		} 
	}
	return false;
}
?>
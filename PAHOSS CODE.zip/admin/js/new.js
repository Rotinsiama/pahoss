	var id = sessionStorage.getItem("tab-id");
	console.log(id);
	if (id==null) 
	{
		location.replace("https://www.google.com/")
	}
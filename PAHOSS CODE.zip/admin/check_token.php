<?php 
header("X-Frame-Options:DENY");
header_remove("Server");
header_remove("X-Powered-By");
header_remove("X-Frame-Options");
session_start();
include 'conn.php';
if (isset($_SESSION['thuruk'])) 
{ 
    $idddd = $_SESSION['thuruk'];
    
    $sql = "SELECT * FROM `user_token` WHERE id=1;";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) 
    {
        // output data of each row
        while($row = mysqli_fetch_assoc($result)) 
        {
            $dbtoken = $row['token']; 
            $token = $_SESSION['token'];
            if($token != $dbtoken)
            {
                session_destroy();
                setcookie("PHPSESSID","",time()-3600,"/"); // delete session cookie
                header('Location: index.php');
            }
        }
    } 
    else 
    {
        session_destroy();
        setcookie("PHPSESSID","",time()-3600,"/"); // delete session cookie
        header('Location: index.php');
    }
}
else
{
    header('Location: index.php');
}
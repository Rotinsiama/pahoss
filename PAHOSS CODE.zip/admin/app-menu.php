    <!-- Navbar-->
    <header class="app-header"><a class="app-header__logo" href="home.php">PAHOSS</a>
      <!-- Sidebar toggle button--><a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
      <!-- Navbar Right Menu-->
      <ul class="app-nav">
        <!-- User Menu-->
        <li class="dropdown"><a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu"><i class="fa fa-user fa-lg"></i></a>
          <ul class="dropdown-menu settings-menu dropdown-menu-right">
            <li><a class="dropdown-item" href="page-user.php"><i class="fa fa-user fa-lg"></i> Profile</a></li>
            <li><a class="dropdown-item" href="logout.php"><i class="fa fa-sign-out fa-lg"></i> Logout</a></li>
          </ul>
        </li>
      </ul>
    </header>
    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">
      <div class="app-sidebar__user"><img class="app-sidebar__user-avatar" src="images/avatar1.png" alt="User Image">
        <div>
          <p class="app-sidebar__user-name">Admin</p>
        </div>
      </div>      

      <ul class="app-menu">
        <li>
          <a class="app-menu__item" href="home.php">
            <i class="app-menu__icon fa fa-plus"></i>
            <span class="app-menu__label">ADD SLOT</span>
          </a>
        </li>
        <li>
          <a class="app-menu__item" href="check_slot.php">
            <i class="app-menu__icon fa fa-check"></i>
            <span class="app-menu__label">CHECK SLOT</span>
          </a>
        </li>
        <li>
          <a class="app-menu__item" href="view_booking_list.php">
            <i class="app-menu__icon fa fa-list"></i>
            <span class="app-menu__label">VIEW BOOKING LIST</span>
          </a>
        </li>
        <li>
          <a class="app-menu__item" href="read_review.php">
            <i class="app-menu__icon fa fa-comments"></i>
            <span class="app-menu__label">READ REVIEW/FEEDBACK</span>
          </a>
        </li>
        <li>
          <a class="app-menu__item" href="view_user_detail.php">
            <i class="app-menu__icon fa fa-eye"></i>
            <span class="app-menu__label">VIEW USER DETAIL</span>
          </a>
        </li>
        <li>
          <a class="app-menu__item" href="system_log.php">
            <i class="app-menu__icon fa fa-tasks"></i>
            <span class="app-menu__label">SYSTEM LOG</span>
          </a>
        </li>        
      </ul>
    </aside>
    <?php include 'conn.php';?>
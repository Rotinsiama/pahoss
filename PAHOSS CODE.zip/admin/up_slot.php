<?php
header("X-Frame-Options:DENY");
header_remove("Server");
header_remove("X-Powered-By");
header_remove("X-Frame-Options");
session_start();
include 'conn.php';
include 'log.php';
if(isset($_SESSION['thuruk']))
{
	if(isset($_POST['submit']))
	{
		$parking_slot_id = strip_tags($_POST['parking_slot_id']);
		$floor = strip_tags($_POST['floor']);
		$vehicule_type = strip_tags($_POST['vehicule_type']);
		$slot_number = strip_tags($_POST['slot_number']);
		$price = strip_tags($_POST['price']);

		if ($parking_slot_id=="0") 
		{
			echo '<script>{alert("Select Parking slot");}</script>';
			echo '<script>{location.replace("home.php")}</script>';
			exit();
		}
		if ($floor=="0") 
		{
			echo '<script>{alert("Select floor");}</script>';
			echo '<script>{location.replace("home.php")}</script>';
			exit();
		}
		if ($vehicule_type=="0") 
		{
			echo '<script>{alert("Select Vehicule Type");}</script>';
			echo '<script>{location.replace("home.php")}</script>';
			exit();
		}
		if ($slot_number=="") 
		{
			echo '<script>{alert("Enter number slot");}</script>';
			echo '<script>{location.replace("home.php")}</script>';
			exit();
		}
		if ($price=="") 
		{
			echo '<script>{alert("Enetr pricing");}</script>';
			echo '<script>{location.replace("home.php")}</script>';
			exit();
		}

		$slot_no = $floor.$slot_number;// concatinate
		$availability = 'yes';
		$available_time = '0';

				//Now insert title of file...
		$stmt = $conn->prepare("INSERT INTO `slot` (`id`, `parking_slot_id`, `slot_number`, `available_time`, `availability`, `pricing`, `slot_type`) VALUES (NULL, ?, ?, ?, ?, ?, ?);");
		$stmt->bind_param("ssssss", $parking_slot_id, $slot_no,$available_time, $availability, $price , $vehicule_type);

		if (!$stmt->execute())
		{
			logger('up_slot.php Fail to Upload Data: Action taken by Admin User-ID->'.$_SESSION["thuruk"]);
			echo '<script>{alert("Fail to Upload!!");}</script>';
					?>
			<script>
				function goBack() 
				{
					window.history.back();
				}
				goBack();
			</script>
			<?php
		}
		else
		{
			logger('up_slot.php Successfully Upload Data: Action taken by Admin User-ID->'.$_SESSION["thuruk"]);
			echo '<script>{alert("Successfully Upload.");}</script>';
			echo '<script>{location.replace("home.php")}</script>';				
		}
	}
	else
	{
		logger('up_slot.php Someone try to upload data without login.');
		echo '<script>{location.replace("home.php")}</script>';
	}
}
else
{
	logger('up_slot.php Someone try to upload_about_us data without login');
	echo '<script>{location.replace("index.php")}</script>';
}
?>
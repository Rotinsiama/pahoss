<?php
    header("X-Frame-Options:DENY");
    header_remove("Server");
    header_remove("X-Powered-By");
    header_remove("X-Frame-Options");
    session_start();
    include 'conn.php';
    $id = $_SESSION["thuruk"];
    $sql = "DELETE FROM `user_token`;";
    if ($conn->query($sql) === TRUE) 
    {
      //echo "Record deleted successfully";
    } 
    session_unset();
    session_destroy();
    //setcookie("PHPSESSID","",time()-3600,"/"); // delete session cookie
	//$url = "index.php";
	if(isset($_GET["session_expired"])) 
	{
		//$url .= "?session_expired=" . $_GET["session_expired"];
		echo '<script>{location.replace("index.php?session_expired=1")}</script>';
	}
	//header("Location:$url");
	echo '<script>{location.replace("index.php")}</script>';
	
?>
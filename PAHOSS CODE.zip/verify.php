

<?php
require('razorpay/config.php');
include 'conn.php';
include 'phpmailer/pay_success.php';
session_start();

require('razorpay/razorpay-php/Razorpay.php');
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;

$success = true;


$error = "Fail Payment, Process.<br>From-PAHOSS";

if (empty($_POST['razorpay_payment_id']) === false)
{
    $api = new Api($keyId, $keySecret);

    try
    {
        // Please note that the razorpay order ID must
        // come from a trusted source (session here, but
        // could be database or something else)
        $attributes = array(
            'razorpay_order_id' => $_SESSION['razorpay_order_id'],
            'razorpay_payment_id' => $_POST['razorpay_payment_id'],
            'razorpay_signature' => $_POST['razorpay_signature']
        );

        $api->utility->verifyPaymentSignature($attributes);
    }
    catch(SignatureVerificationError $e)
    {
        $success = false;
        $error = 'Razorpay Error : ' . $e->getMessage();
    }
}

if ($success === true)
{
 
    $id = $_SESSION['thuruk_user'];

    $sql = "SELECT email, name FROM users WHERE id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) 
    {
      // output data of each row
        while($row = $result->fetch_assoc()) 
        {
            $name = $row["name"];
            $email = $row['email'];
        }
    }




    $Pahoss_parking_name = $_POST['owner_name'];
    $pahoss_parking_id = $_POST['pahoss_parking_id'];
    $slot_id = $_POST['slot_id'];
    $from = $_POST['from'];
    $to = $_POST['to'];
    $pricing = $_POST['pricing'];
    $payment_id = $_POST['razorpay_payment_id'];
    $customer_id = $_SESSION['thuruk_user']; 

    //Cal totoal Amount

    $date1=date_create($from);
    $date2=date_create($to);
    $diff = date_diff($date1,$date2); 
    $amount = $pricing * $diff->format("%a");


    $sql = "INSERT INTO booking (customer_name, customer_id, owner_name, pahoss_parking_id, slot_id, booking_time, expire_time, payment_id, amount)
    VALUES ('$name', '$customer_id', '$Pahoss_parking_name', '$pahoss_parking_id','$slot_id', '$from', '$to', '$payment_id', '$amount')";

    if ($conn->query($sql) === TRUE) 
    {
        $sql = "UPDATE slot SET available_time='$to', availability='no' WHERE id = '$slot_id'";

        if ($conn->query($sql) === TRUE) 
        {
            //echo "Record updated successfully ";
            success($email);        } 
        else 
        {
            echo "Error updating record: " . $conn->error;
        }
      //echo "New record created successfully";
    } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
else
{
    echo "Fail Payment, Process.<br>From-PAHOSS";
}
//echo $html;

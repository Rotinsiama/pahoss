<?php
header("X-Frame-Options:DENY");
header_remove("Server");
header_remove("X-Powered-By");
header_remove("X-Frame-Options");
session_start();
include 'conn.php';
include 'log.php';
if(isset($_SESSION['thuruk_user']))
{
	$id = $_SESSION['thuruk_user'] ;
	if(isset($_POST['submit']))	
	{
		$name = strip_tags($_POST['name']);
		if ($name=="") 
		{
			echo '<script>{alert("Enter name..");}</script>';
			echo '<script>{location.replace("enter_details.php")}</script>';
			exit();
		}
		elseif(strlen($name)>30)
		{
			echo '<script>{alert("Name are too long::Only 30 are allow. Try Again.");}</script>';
			echo '<script>{location.replace("enter_details.php")}</script>';
			exit();
		}
		$gender = strip_tags($_POST['gender']);
		if ($gender=="") 
		{
			echo '<script>{alert("Select Gender..");}</script>';
			echo '<script>{location.replace("enter_details.php")}</script>';
			exit();
		}
		$mobile = strip_tags($_POST['mobile']);
		if ($mobile=="") 
		{
			echo '<script>{alert("Enter mobile number..");}</script>';
			echo '<script>{location.replace("enter_details.php")}</script>';
			exit();
		}
		elseif(strlen($mobile)!==10)
		{
			echo '<script>{alert("Enter 10 digit mobile number");}</script>';
			echo '<script>{location.replace("enter_details.php")}</script>';
			exit();			
		}
		$address = strip_tags($_POST['address']);
		if ($address=="") 
		{
			echo '<script>{alert("Enter address..");}</script>';
			echo '<script>{location.replace("enter_details.php")}</script>';
			exit();
		}
		elseif(strlen($address)>400)
		{
			echo '<script>{alert("Address are too long::Only 30 are allow. Try Again.");}</script>';
			echo '<script>{location.replace("enter_details.php")}</script>';
			exit();
		}
		$vehicle_type = strip_tags($_POST['vehicle_type']);
		if ($vehicle_type=="Vehicle Type") 
		{
			echo '<script>{alert("Select vehicle type..");}</script>';
			echo '<script>{location.replace("enter_details.php")}</script>';
			exit();
		}
		$vehicle_number = strip_tags($_POST['vehicle_number']);
		if ($vehicle_number=="") 
		{
			echo '<script>{alert("Enter vehicle number..");}</script>';
			echo '<script>{location.replace("enter_details.php")}</script>';
			exit();
		}

		$gps_lat = strip_tags($_POST['gps_lat']);
		if ($gps_lat=="") 
		{
			echo '<script>{alert("Click Get current GPS coordinate..");}</script>';
			echo '<script>{location.replace("enter_details.php")}</script>';
			exit();
		}
		$gps_long = strip_tags($_POST['gps_long']);
		if ($gps_long=="") 
		{
			echo '<script>{alert("Click Get current GPS coordinate..");}</script>';
			echo '<script>{location.replace("enter_details.php")}</script>';
			exit();
		}
		
		else
		{
			$stmt = $conn->prepare("UPDATE `users` SET `name` = ?,`gender` = ?, `mobile` = ?, `address` = ?, `vehicle_type` = ?, `vehicle_number` = ?, `gps_lat` = ?, `gps_long` = ? WHERE `users`.`id` = $id;");
			$stmt->bind_param("ssssssss", $name, $gender, $mobile, $address, $vehicle_type, $vehicle_number, $gps_lat, $gps_long);


			if (!$stmt->execute())
			{
				logger('up_new_user_data.php Fail to up: Action taken by  User-ID->'.$_SESSION["thuruk_user"]);
				echo '<script>{alert("Fail to Update. try again");}</script>';
				echo '<script>{location.replace("up_newuser_data.php")}</script>';
				exit();
			}
			else
			{
				logger('up_new_user_data.php Successfully Up: Action taken by  User-ID->'.$_SESSION["thuruk_user"]);
				echo '<script>{alert("Thank you for Sign-Up.");}</script>';
				echo '<script>{location.replace("home.php")}</script>';
				exit();
				//going back to page...
			}	
		}		
	}
	else
	{
		logger('up_new_user_data.php Someone try to upload data without login.');
		echo '<script>{location.replace("enter_details.php")}</script>';
		exit();
	}
}
else
{
	logger('up_new_user_data.php Someone try to up data without login');
	echo '<script>{location.replace("login.php")}</script>';
	exit();
}
?>
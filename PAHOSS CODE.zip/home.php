<?php
header("X-Frame-Options:DENY");
header_remove("Server");
header_remove("X-Powered-By");
header_remove("X-Frame-Options");
session_start();
if(isset($_SESSION['thuruk_user']))
{
?>
<!DOCTYPE html>
<html lang="en">
  <head>
  <title>Pahoss</title>
  <link rel="icon" href="favicon.png" type="image/gif" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
<script type="text/javascript">
  var id = sessionStorage.getItem("tab-id");
  if (id==null) 
  {
    //location.replace("https://www.google.com/")
  }

    function showPosition() 
    {
      if(navigator.geolocation) 
      {
            navigator.geolocation.getCurrentPosition(function(position) {
                var latitude =  position.coords.latitude;
                //document.getElementById("result").innerHTML = positionInfo;
                var longitude =  position.coords.longitude;
                //document.getElementById("result1").innerHTML = positionInfo;
              var link = "index.php?lat="+latitude+"&long="+longitude;
              location.replace(link);


            });
        } else {
            alert("Sorry, your browser does not support HTML5 geolocation.");
        }
        varr = "a"
    }
</script>  
<script type="text/javascript">
  var id = sessionStorage.getItem("tab-id");
  if (id==null) 
  {
    //location.replace("https://www.google.com/")
  }
</script>
<style type="text/css">
  body
  {
      -webkit-touch-callout: none; /* iOS Safari */ 
      -webkit-user-select: none; /* Safari */ 
       -khtml-user-select: none; /* Konqueror HTML */ 
         -moz-user-select: none; /* Firefox */ 
          -ms-user-select: none; /* Internet Explorer/Edge */ 
              user-select: none; /* Non-prefixed version, currently 
                                    supported by Chrome and Opera */      
  } 
    .center 
    {
      margin: auto;
      width: 50%;
      border: 1px solid #73AD21;
      padding:20px;
      background-color:  #cc00cc; 
    }
    .center:hover
    {
      background-color: white;
      border: 1px solid white; 
    }
    @media only screen and (max-width: 700px)
    {
      .center
      {
        width: 100%;
      }
    }   
</style>
  <body class="app sidebar-mini">

    <?php include "app-menu.php";?>

    <main class="app-content">
      <div class="app-title" >
        <div>
          <h1><i class="fa fa-edit"></i>Welcome to PAHOSS PARKING</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="home.php">Home</a></li>
        </ul>
      </div>
            <div style="width: 100%;margin-top: 30px; ">
        <div id="center" onclick="showPosition();" class="center" style="font-size: 25px; margin-bottom: 50px; margin-top: 50px; border-radius: 5px; ">
              Click Search Parking Slot Near me.<i class="far fa-car-building" style="font-size: 50px;t"></i>
        </div>
       </div> 
      <div style="width: 100%;float: left;text-align: center;background-color: lightgray;">
        <iframe src="https://www.google.com/maps/d/embed?mid=1XueDMSZPYdBMR1saV6DFei6t4sAfhLAN" style="width: 100%; float: left;" height="400"></iframe>
      </div>
      
    </main>
    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <!-- Google analytics script-->
    <script type="text/javascript">
      if(document.location.hostname == 'pratikborsadiya.in') {
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
        ga('create', 'UA-72504830-1', 'auto');
        ga('send', 'pageview');
      }
    </script>
  </body>
</html>
<?php
}
else
{
  echo '<script>{location.replace("login.php")}</script>';
}
?>
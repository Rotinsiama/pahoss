<?php
header("X-Frame-Options:DENY");
header_remove("Server");
header_remove("X-Powered-By");
header_remove("X-Frame-Options");
session_start();
if(isset($_SESSION['thuruk_user']))
{
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Pahoss</title>
    <link rel="icon" href="favicon.png" type="image/gif" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
<script type="text/javascript">
	var id = sessionStorage.getItem("tab-id");
	if (id==null) 
	{
		//location.replace("https://www.google.com/")
	}
</script>
<style type="text/css">
  body
  {
      -webkit-touch-callout: none; /* iOS Safari */ 
      -webkit-user-select: none; /* Safari */ 
       -khtml-user-select: none; /* Konqueror HTML */ 
         -moz-user-select: none; /* Firefox */ 
          -ms-user-select: none; /* Internet Explorer/Edge */ 
              user-select: none; /* Non-prefixed version, currently 
                                    supported by Chrome and Opera */      
  }  
  
  .slot
  {
    width: 23%; 
    float: left;  
    height: 60px; 
    margin-left: 5px; 
    margin-top: 5px; 
    border: 1px solid black;  
    border-radius: 6px;  
    background-color: white;  
  }
  .slot:hover
  {
    background-color: lightgray;
    border: 1px solid white;
  }
  .review-col
  {
    text-align: left; 
    margin-top: 5px; 
    width: 21%; 
    margin-right: 2%;
    margin-left: 2%; float: left; 
    border: 1px solid white; 
    border-top-right-radius: 50px;
    border-bottom-left-radius: 10px;
  }
  #icon
  {
    width: 100%; 
    margin-top: 20%;'
  }
  
  @media only screen and (max-width: 700px)
  {
    .slot
    {
      width: 97%;
    }
    .review-col
    {
      width: 100%;
      margin: 0px;
      margin-top: 10px; 
    }
    #icon
    {
      margin-top: 0;
      height: 100%;
      width: auto;
    }
  
  }

</style>
  <body class="app sidebar-mini" style="background-color: lightgray;">

    <?php include "app-menu.php";?>
    
    <main class="app-content" style="background-color: lightgray;">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-edit"></i>BOOK PARKING SLOT</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="home.php">Home</a></li>
        </ul>
      </div>
      <?php 
        if (isset($_GET['parking_slot_id'])) 
        {
          $id = $_GET['parking_slot_id'];
          $mylat = $_GET['mylat'];
          $mylong = $_GET['mylong'];
          
          $sql = "SELECT * FROM `parking_slot` WHERE id = $id;";
          $result = $conn->query($sql);
          if ($result->num_rows > 0) 
          {
            while($row = $result->fetch_assoc()) 
            {
              $owner_name = $row["owner_name"];
              $contact = $row["contact"];
              $address = $row["address"];
              $gps_lat = $row["gps_lat"];
              $gps_long = $row["gps_long"];
            }


      ?>
      <div style="width: 100%;float: left;text-align: center;">
        <div style="width: 100%;float: left;text-align: center;color: gray; padding-bottom: 20px;">
          <h4 style="margin-top: 30px;"><?php echo $owner_name;?>:</h4>
          <hr>
        </div>
          <span style="font-weight: bolder;">
          Contact:<?php echo $contact;?><br>
          Address:<?php echo $address;?><br>
          Latitude:<?php echo $gps_lat; ?><br>
          Longitude:<?php echo $gps_long; ?><br>
          <br>
          </span>
        <?php
          }
       

              static $l=0;
              $slot_number = array();
              $parking_slot_id = array();
              $availability = array();

              $sql = "SELECT * FROM `slot` WHERE parking_slot_id = '$id';";
              $result = $conn->query($sql);
              if ($result->num_rows > 0) 
              {
                // output data of each row
                while($row = $result->fetch_assoc()) 
                {
                  $slot_id[$l] = $row['id'];
                  $pahoss_parking_id[$l] = $row['parking_slot_id'];
                  $slot_number[$l] = $row['slot_number'];
                  $available_time[$l] = $row['available_time'];
                  $availability[$l] = $row['availability'];
                  $pricing[$l] = $row['pricing']; 
                  $slot_type[$l] = $row['slot_type']; 
                  $l++;
                }
              }
              $nnn = 0;
              static $z = 0;
              $sql = "SELECT * FROM `review` WHERE pahoss_parking_id = '$id';";
              $result = $conn->query($sql);
              if ($result->num_rows > 0) 
              {
                // output data of each row
                while($row = $result->fetch_assoc()) 
                {
                  $writer[$z] = $row['writer'];
                  $text[$z] = $row['text'];
                  $rating[$z] = $row['rating'];
                  $z++;
                }
                
                $nnn = count($writer);
              }

              
          }
        ?>   
        <iframe src="https://www.google.com/maps/embed?pb=!1m20!1m8!1m3!1d58439.980500975864!2d92.70763794807131!3d23.729586534634937!3m2!1i1024!2i768!4f13.1!4m9!3e0!4m3!3m2!1d<?php echo $mylat; ?>!2d<?php echo  $mylong;?>!4m3!3m2!1d<?php echo $gps_lat?>!2d<?php echo $gps_long;?>!5e0!3m2!1sen!2sin!4v1621752638483!5m2!1sen!2sin"  height="400" style="border:1px solid gray; width: 100%;" allowfullscreen="" loading="lazy"></iframe> 

        <div style="width: 100%; float: left; margin: 30px 0px; text-align: center;">
          <div class="review" style="width: 100%; float: left; text-align: center; margin-bottom: 30px;">
            <h6>Customer Review:</h6>
            <?php
            if($nnn !== 0)
            {
              for ($x=0; $x < $nnn; $x++) 
              { 
              ?>
              <div class="review-col" >
                <p style="padding: 10px">
                  <span style="color: #cc00cc"><?php echo $writer[$x];?></span><br>
                  <?php echo $text[$x].'<br>';
                  for ($a=0; $a < $rating[$x] ; $a++) 
                  { 
                    echo '<i class="fa fa-star" aria-hidden="true" style="float:right;color:green;"></i>';
                  }
                  ?>
                </p>
              </div>
              <?php
              }
            }
            ?>
          </div>
          <!--- ////////////////////////////////////////////////// --->
          <h2>List of Slot</h2>
          <br>
          <?php
            $n = count($slot_number);
            for ($i=0; $i < $n ; $i++) 
            { 
            ?>
              <div class="slot">
                <div style="width: 20%; float: left; height: inherit; border-right: 1px solid; ">
                  <?php
                  if ($slot_type[$i] == 4) 
                  {
                    echo "<img src='car.png' id='icon' >";
                  }
                  elseif ($slot_type[$i] == 2) 
                  {
                    echo "<img src='bike.png' id='icon' >";
                  }
                  ?>
                </div>
                <div style="padding: 2px; font-size: 12px; width: 60%; float: left; height: 100%; text-align: left;">
                  <?php echo $slot_number[$i];
                    if($available_time[$i] == 0)
                    {
                      echo "<br>Availabe Now";
                    }
                    else
                    {
                      echo "<br>Will be Availabe from:".$available_time[$i];
                    }
                    ?>
                  
                </div>
                <?php 
                if($availability[$i] == 'yes')
                {
                  ?>
                  <div onclick="window.location='cal.php?owner_name=<?php echo $owner_name;?>&pahoss_parking_id=<?php echo $pahoss_parking_id[$i] ;?>&slot_id=<?php echo $slot_id[$i];?>&pricing=<?php echo $pricing[$i];?>&slot_type=<?php echo $slot_type[$i];?>'" id='book' style="background-color: #00cc00; border-bottom-right-radius: 6px; border-top-right-radius: 6px; width: 20%; float: left;height: 100%; border-left: 1px solid;">
                    Book Now
                  </div>
                  <?php
                }
                else if ($availability[$i] == 'no') 
                {
                ?>
                  <div id='book' style="background-color: red; border-bottom-right-radius: 6px; border-top-right-radius: 6px; width: 20%; float: left;height: 100%; border-left: 1px solid;">
                    <i class="fas fa-times" style="color: lightgray; font-size: 30px;margin-top: 30%;"></i>
                  </div>
                <?php
                }
                ?>
              </div>
            <?php 

            }

            ?>
        </div>
      </div>
    </main>
    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <!-- Google analytics script-->
    <script type="text/javascript">
      if(document.location.hostname == 'pratikborsadiya.in') {
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
        ga('create', 'UA-72504830-1', 'auto');
        ga('send', 'pageview');
      }
    </script>
  </body>
</html>
<?php
}
else
{
  echo '<script>{location.replace("login.php")}</script>';
}
?>
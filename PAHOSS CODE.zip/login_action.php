<?php	
// Start the session
	session_start();
    header("X-Frame-Options:DENY");
    header_remove("Server");
    header_remove("X-Powered-By");
    header_remove("X-Frame-Options");
	include 'conn.php';
    include 'log.php';
	if(isset($_POST['login'])) 
	{

		$email = $_POST['email'];			
		$password = $_POST['password'];

		$captcha_id = $_POST['captcha_id'];
		$captcha = $_POST['captcha'];
		$i = 1;
		//Checking captcha
	    $sql1 = "SELECT * FROM `captcha_table` ORDER BY id DESC LIMIT 3;";
	    $result = mysqli_query($conn, $sql1);

	    if (mysqli_num_rows($result) > 0) 
	    {
	      // output data of each row
	      while($row = mysqli_fetch_assoc($result)) 
	      {
	        $captcha_id_db[$i] = $row["captcha_id"];
	        $captcha_db[$i] = $row["captcha"];
	      	$i++;
	      }
	    } 
	    else 
	    {
	    ?>
	      <script type="text/javascript">
	        location.replace("login.php");
	      </script>
	    <?php
	    exit();
	    }

	    if($captcha==$captcha_db[3] and $captcha_id_db[3]==$captcha_id)
	    {
	    	$del = "DELETE FROM `captcha_table` WHERE `captcha_table`.`captcha_id` = '$captcha_id_db[3]';";
	    	if ($conn->query($del) === TRUE) 
	    	{
			  //echo "Record deleted successfully";
			} 
			// fetching SALT from DB...
    		$stmt = $conn->prepare("SELECT salt, email  FROM users  WHERE email =? LIMIT 1;");
    		$stmt->bind_param('s', $email);
        	$stmt->execute();
        	$stmt->bind_result($dbsalt, $dbemail);// get the database output
        	$stmt->store_result();
        	if($stmt->num_rows == 1)  //To check if the row exists
            {
    		    // output data of each row
    		    if($stmt->fetch()) 
    			{
    			    if(md5($email)==md5($dbemail))
    			    {
        				$pas = $password.$dbsalt;
          			    $newpwdhash  = hash('sha256', $pas);
                        
                        // Fetching and cheching match password and email----
        				$stmt = $conn->prepare("SELECT id,  email FROM users  WHERE email =? AND password = ? LIMIT 1;");
        				$stmt->bind_param('ss', $email, $newpwdhash);
        		    	$stmt->execute();
        		    	$stmt->bind_result($id, $email );// get the database output
        		    	$stmt->store_result();
        		    	if($stmt->num_rows == 1)  //To check if the row exists
        		        {
        				    // output data of each row
        				    if($stmt->fetch()) 
        					{
        					    // Set session variables
        					    $_SESSION["thuruk_user"] = $id;
               					    

                                logger('Login.php Login Attempted Successfull UserName= '.$email);
                                echo '<script>{location.replace("index.php")}</script>';
                                        exit();
        					}
        				}
        				else 
        				{
                            logger('Login.php Login Attempted Failed Name= '.$email);
        				    header('Location:login.php?error=ERROR: Invalid Email Or Password!');
        				   	exit();
        				} 	
    			    }
    			    else
    			    {
                        logger('Login.php Login Attempted Failed Name= '.$email);
            		    header('Location:login.php?error=ERROR: Invalid Email Or Password!');
            		    exit();
    			    }
    			}
    		}
    		else 
    		{
                logger('Login.php Login Attempted Failed Name= '.$email);
    		    header('Location:login.php?error=ERROR: Invalid Email Or Password!');
    		    exit();
    		}
        }
	    else
	    {
            logger('Login.php Login Attempted Failed Name= '.$email.' Captcha not match');
			header('Location:login.php?error=Not Match Captcha!');
			exit();
	    }
	}
	else
	{
        logger('Login.php Login Attempted Failed: Someone try to login without userid or password');
		header('Location:login.php?error=ERROR: Request terminating...!');
		exit();
	}
?>
<?php
    header("X-Frame-Options:DENY");
    header_remove("Server");
    header_remove("X-Powered-By");
    header_remove("X-Frame-Options");
    session_start();
    session_unset();
    session_destroy();
    setcookie("PHPSESSID","",time()-3600,"/"); // delete session cookie
	$url = "login.php";
	if(isset($_GET["session_expired"])) 
	{
		$url .= "?session_expired=" . $_GET["session_expired"];
	}
	header("Location:$url");
?>
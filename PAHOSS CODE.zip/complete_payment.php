<?php
session_start();
include 'conn.php';
include 'phpmailer/pay_success.php';
if(isset($_GET['payment_id']))
{
    $id = $_SESSION['thuruk_user'];

    $sql = "SELECT email FROM users WHERE id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) 
    {
      // output data of each row
        while($row = $result->fetch_assoc()) 
        {
            $email = strip_tags($row['email']);
        }
    }
	$payment_id = $_GET['payment_id'];
	$sql = "SELECT * FROM temp_pay ORDER BY id DESC LIMIT 1";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) 
	{
	  	while($row = $result->fetch_assoc()) 
	  	{
	     	$customer_name= strip_tags($row["customer_name"]);
	     	$customer_id= strip_tags($row["customer_id"]);
	     	$pahoss_parking_id= strip_tags($row["pahoss_parking_id"]);
	     	$owner_name= strip_tags($row["owner_name"]);
	     	$slot_id= strip_tags($row["slot_id"]);
	     	$booking_time= strip_tags($row["booking_time"]);
	     	$expire_time= strip_tags($row["expire_time"]);
	     	$amount= strip_tags($row["amount"]);
	  	}

	 	$sql = "INSERT INTO booking (customer_name, customer_id, owner_name, pahoss_parking_id, slot_id, booking_time, expire_time, payment_id, amount, cancel)
	    VALUES ('$customer_name', '$customer_id', '$owner_name', '$pahoss_parking_id','$slot_id', '$booking_time', '$expire_time', '$payment_id', '$amount', '0')";

	    if ($conn->query($sql) === TRUE) 
	    {
	        $sql = "UPDATE slot SET available_time='$expire_time', availability='no' WHERE id = '$slot_id'";

	        if ($conn->query($sql) === TRUE) 
	        {
	            //success($email); 
	            //echo "OK";
	            // Sending Email Using JavaScript
	            ?>
				<script src= "smtp.js"></script> 
				<script type="text/javascript"> 
					//function sendEmail(){ 
					Email.send({
						
						Host: "smtp.gmail.com", 
						Username: "elevenjune.in@gmail.com", 
						Password: "qoqjswrconidocnp",
						// You can use app password or original password
						//Password: "Ngurlunghnemi",
						Port: "587",
						To: '<?php echo $email;?>', 
						From: "pahoss@gmail.com",
						Subject: "PAHOSS:Payment Success", 
						Body: "THANK YOU <br> FOR <br> USING PAHOSS SURVICE.", 
					}) 
						.then(function (message) 
						{
							location.replace("index.php"); 
							//alert("<?php echo $email;?>") 
						}); 
					//} 
				</script> 

	            <?php
	        } 
	        else 
	        {
	            echo "Error updating record: " . $conn->error;
	        }
	      //echo "New record created successfully";
	    } else {
	      echo "Error: " . $sql . "<br>" . $conn->error;
	    }
	} 
	else 
	{
	  echo "0 results";
	}
}
?>
<style type="text/css">
	//Page loading css
	#loader 
    {

    } 
    @keyframes spin 
    { 
    	100%
    	{ 
    		transform: rotate(360deg); 
    	} 
    } 
    div.center 
    { 
        position: absolute; 
        top: 0; 
        bottom: 0; 
        left: 0; 
        right: 0; 
        margin: auto; 
 	}
</style>
<div id="loader" class="center" style="border: 16px solid white; border-radius: 50%; border-top: 16px solid #b53389;border-bottom: 16px solid #db7093;width: 100px;height: 100px;-webkit-animation: spin 2s linear infinite;animation: spin 1s linear infinite;">
</div>  
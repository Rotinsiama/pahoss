<?php
header("X-Frame-Options:DENY");
header_remove("Server");
header_remove("X-Powered-By");
header_remove("X-Frame-Options");
session_start();
include 'conn.php';
if(isset($_SESSION['thuruk_user']))//checking session
{
	if($_POST['update'])
	{
		$id = $_SESSION['thuruk_user'];
		$current_password = strip_tags($_POST['current_password']);
		$new_password = strip_tags($_POST['new_password']);
		$confirm_password = strip_tags($_POST['confirm_password']);
		if($new_password==$confirm_password)
		{
    		$stmt = $conn->prepare("SELECT `salt`,`old_salt` FROM `users` WHERE `users`.`id` = ?;");
    		$stmt->bind_param('s', $id);
        	$stmt->execute();
        	$stmt->bind_result($dbsalt, $old_dbsalt);// get the database output
        	$stmt->store_result();
        	if($stmt->num_rows == 1)  //To check if the row exists
            {
    		    // output data of each row
    		    if($stmt->fetch()) 
    			{
    				$pas = $current_password.$dbsalt;
      			    $newpwdhash  = hash('sha256', $pas);
      			    $sql = "SELECT `password`, `old_password` FROM `users` WHERE `users`.`password` = '$newpwdhash';";
					$result = $conn->query($sql);
					if ($result->num_rows > 0) 
					{
					  	// output data of each row
					  	while($row = $result->fetch_assoc()) 
					  	{
					    	$pwd= $row["password"];
							$old_pwd= $row["old_password"];
	    		        	$pas = $new_password.$dbsalt;
	    		        	$pas1 = $new_password.$old_dbsalt;
	      			    	$newpwdhash_new  = hash('sha256', $pas);
	    		        	$newpwdhash_new1  = hash('sha256', $pas1);
	    		        	if($newpwdhash_new == $pwd)
	    		        	{
	            		    	echo "<script type='text/javascript'>alert('Choose stronger password!! Try Again')</script>";
	            		   		echo '<script>{location.replace("page-user.php")}</script>';    		        		
	    		        		exit();
	    		        	}
	    		        	elseif($old_pwd == $newpwdhash_new1) 
	    		        	{
	            		    	echo "<script type='text/javascript'>alert('KKKK-Choose stronger password!! Try Again')</script>";
	            		   		echo '<script>{location.replace("page-user.php")}</script>';    		        		
	    		        		exit();
	    		        	}
	    		        	else
	    		        	{
		     		            $salt = substr(bin2hex(random_bytes(100)), 0, 100);
		    		           	$pas = $new_password.$salt;
		  			            $newpwdhash  = hash('sha256', $pas);
		                		$del = "UPDATE `users` SET `old_password` = '$pwd',`password` = '$newpwdhash', `salt` = '$salt', `old_salt` = '$dbsalt' WHERE `users`.`id` = $id;";
		                		if ($conn->query($del)==-TRUE) 
		                		{
		                			echo '<script>{alert("Successfully Change Password.");}</script>';
		                            $id = $_SESSION["thuruk_user"];
		                            $sql = "DELETE FROM `user_token` WHERE `user_token`.`userid` = $id;";
		                            if ($conn->query($sql) === TRUE) 
		                            {
		                                  //echo "Record deleted successfully";
		                            } 
		                            session_unset();
		                            session_destroy();
		                            //setcookie("PHPSESSID","",time()-3600,"/");
		                			echo '<script>{location.replace("login.php")}</script>';	
		                			//going back to page...
		                		}
		                		else
		                		{
		                			echo '<script>{alert("Fail to Chage password.");}</script>';
		                			echo '<script>{location.replace("page-user.php")}</script>';
		                		}	        		
	    		        	} 
					  	}
    		        }
            		else 
            		{
	        		    echo "<script type='text/javascript'>alert('Something worng!! Try Again')</script>";
	        		   	echo '<script>{location.replace("page-user.php")}</script>';            		
            		}
    			}
    			else
    			{
        		    echo "<script type='text/javascript'>alert('Something worng!! Try Again')</script>";
        		   	echo '<script>{location.replace("page-user.php")}</script>';
    			}
            }
            else
            {
        	    echo "<script type='text/javascript'>alert('Something worng!! Try Again')</script>";
            	echo '<script>{location.replace("page-user.php")}</script>';
            }
		}
		else
		{
			echo '<script>{alert("Given Password  Not Match!.");}</script>';
			echo '<script>{location.replace("page-user.php")}</script>';		    
		}
	}
	else
	{
		echo '<script>{alert("Requiest terminating...");}</script>';
        header("Location:login.php");
	}
}
else
{
	//if session is expered go back to login
    header("Location:login.php");
}
?> 

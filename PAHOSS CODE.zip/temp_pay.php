<?php
    $id = $_SESSION['thuruk_user'];

    $sql = "SELECT  name FROM users WHERE id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) 
    {
      // output data of each row
        while($row = $result->fetch_assoc()) 
        {
            $name = $row["name"];
        }
    }
    $customer_id = $_SESSION['thuruk_user']; 

    //Cal totoal Amount

    $date1=date_create($from);
    $date2=date_create($to);
    $diff = date_diff($date1,$date2); 
    $amount = ($pricing * ($diff->format("%a")+1));


    $sql = "INSERT INTO temp_pay (customer_name, customer_id, owner_name, pahoss_parking_id, slot_id, booking_time, expire_time, amount)
    VALUES ('$name', '$customer_id', '$Pahoss_parking_name', '$pahoss_parking_id','$slot_id', '$from', '$to', '$amount')";

    if ($conn->query($sql) === TRUE) 
    {
    ?>
            <div style="width: 100%; float: left;margin-top: 5px;">
                <form><script src="https://checkout.razorpay.com/v1/payment-button.js" data-payment_button_id="pl_HELkH8crG19D3Y" async> </script> 
                </form>              
            </div>
    <?php
    } 
    else 
    {
      echo "Error: " . $sql . "<br>" . $conn->error;
    }

<!--  The entire list of Checkout fields is available at
 https://docs.razorpay.com/docs/checkout-form#checkout-fields -->
<div id="loader" class="center" style="border: 16px solid white; border-radius: 50%; border-top: 16px solid #b53389;border-bottom: 16px solid #db7093;width: 100px;height: 100px;-webkit-animation: spin 2s linear infinite;animation: spin 1s linear infinite;">
</div>           
<form id="form" action="verify.php" method="POST">
  <script
    src="https://checkout.razorpay.com/v1/checkout.js"
    data-key="<?php echo $data['key']?>"
    data-amount="<?php echo $data['amount']?>"
    data-currency="INR"
    data-name="<?php echo $data['name']?>"
    data-image="<?php echo $data['image']?>"
    data-description="<?php echo $data['description']?>"
    data-prefill.name="<?php echo $data['prefill']['name']?>"
    data-prefill.email="<?php echo $data['prefill']['email']?>"
    data-prefill.contact="<?php echo $data['prefill']['contact']?>"
    data-notes.shopping_order_id="3456"
    data-order_id="<?php echo $data['order_id']?>"
    <?php if ($displayCurrency !== 'INR') { ?> data-display_amount="<?php echo $data['display_amount']?>" <?php } ?>
    <?php if ($displayCurrency !== 'INR') { ?> data-display_currency="<?php echo $data['display_currency']?>" <?php } ?>
  >
  </script> 
  <style type="text/css">
    .razorpay-payment-button
    {
      display: none;
    }
                //Page loading css
            #loader 
            {

            } 
            @keyframes spin 
            { 
                100%
                { 
                    transform: rotate(360deg); 
                } 
            } 
            div.center 
            { 
                display: none;
                position: absolute; 
                top: 0; 
                bottom: 0; 
                left: 0; 
                right: 0; 
                margin: auto; 
            }
        </style>
              <input type="hidden" name="owner_name" value="<?php echo $Pahoss_parking_name;?>">
              <input type="hidden" name="pahoss_parking_id" value="<?php echo $pahoss_parking_id ;?>">
              <input type="hidden" name="slot_id" value="<?php echo $slot_id ;?>">
              <input type="hidden" name="from" value="<?php echo $from?>">
              <input type="hidden" name="to" value="<?php echo $to;?>">
              <input type="hidden" name="pricing" value="<?php echo $pricing; ?>">
              <input type="hidden" name="checkout" value="automatic">
              <input type="submit" id="book" name="sumbit" value="Complete Booking" style="width: 60%; padding:10px; background-color: #00cc00; border: 1px solid #00cc00; border-radius: 6px;">
  <!-- Any extra fields to be submitted with the form but not sent to Razorpay -->
  <input type="hidden" name="shopping_order_id" value="3456">
</form>
<script type="text/javascript">
  document.getElementById("book").addEventListener("click", function() 
  {
    document.getElementById("loader").style.display = 'block';
    document.getElementById("form").style.display = 'none';
    document.getElementById("data").style.display = 'none';
    document.getElementById("processing").style.display = 'block';

  });
</script>
